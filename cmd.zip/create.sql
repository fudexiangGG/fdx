CREATE TABLE IF NOT EXISTS `users`(
   `id` INT UNSIGNED  AUTO_INCREMENT,
   `username` VARCHAR(255) NOT NULL,
   `mobile` VARCHAR(255) NOT NULL,
   `level` VARCHAR(255) NOT NULL,
   `password` VARCHAR(255) NOT NULL,
   `count` bigint NOT NULL,
   `count_time` bigint NOT NULL,
   `amount` bigint NOT NULL,
    `role` VARCHAR(255) NOT NULL,
    `create_time` bigint NOT NULL,
     `toekn_time` bigint NOT NULL,
       `token` VARCHAR(255) NOT NULL,
   PRIMARY KEY ( `id` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tickets`(
    `id` INT UNSIGNED  AUTO_INCREMENT,
    `username` VARCHAR(255) NOT NULL,
    `status` VARCHAR(255) NOT NULL,
    `ticket_json` text Not NULL ,
    `create_time` bigint NOT NULL,

    PRIMARY KEY ( `id` )
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `ticket_dialogs`(
    `id` INT UNSIGNED,
    `dialog` text Not NULL ,
   
    PRIMARY KEY ( `id` )
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;

