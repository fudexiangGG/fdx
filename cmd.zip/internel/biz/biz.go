package biz

import (
	"database/sql/driver"
	"encoding/json"
	"log"
	"ltd_backend/internel/transport"
	"sort"
)

type Biz struct {
	mydb Biz_interface
	log  *log.Logger
}

type TicketDialog struct {
	Id     string `gorm:"primaryKey;column:id;type:varchar;size:255;not null" json:"id,omitempty"`
	Dialog string `gorm:"primaryKey;column:dialog;type:text;dialog;not null" json:"dialog,omitempty"`
}

type Ticket struct {
	Id                    string `gorm:"primaryKey;column:id;type:varchar;size:255;autoIncrement;not null" json:"id,omitempty"`
	Username              string `gorm:"column:username;type:varchar;size:255;not null" json:"username,omitempty"`
	CreateTime            int64  `gorm:"column:create_time;type:bigint" json:"create_time,omitempty"`
	Status                string `gorm:"column:status;type:varchar;size:255;not null" json:"status,omitempty"`
	TicketJson            string `gorm:"primaryKey;column:ticket_json;type:text;ticket_json;not null" json:"ticket_json,omitempty"`
	Score                 int    `gorm:"column:score;type:int" json:"score,omitempty"`
	Comment               string `gorm:"column:comment;type:varchar" json:"comments,omitempty"`
	UserCommentStatus     string `gorm:"column:user_comment_status;type:varchar" json:"user_comment_status,omitempty"`
	EngineerCommentStatus string `gorm:"column:engineer_comment_status;type:varchar" json:"engineer_comment_status,omitempty"`
	UserFileStatus        string `gorm:"column:user_file_status;type:varchar" json:"user_file_status,omitempty"`
	EngineerFileStatus    string `gorm:"column:engineer_file_status;type:varchar" json:"engineer_file_status,omitempty"`
	EndTime               int64  `gorm:"column:end_time;type:bigint" json:"end_time,omitempty"`
	ChangeHistory         string `gorm:"column:change_history;type:varchar" json:"change_history,omitempty"`
}

type TicketWrapper struct {
	Ticket []Ticket
	By func(p,q *Ticket) bool
}

type SortBy func(p,q *Ticket) bool 

func (t TicketWrapper) Len() int {
	return len(t.Ticket)
}

func (t TicketWrapper) Swap(i,j int) {
	t.Ticket[i] , t.Ticket[j] = t.Ticket[j] , t.Ticket[i]
}

func (t TicketWrapper) Less(i,j int) bool {
	return t.By(&t.Ticket[i],&t.Ticket[j])
}

func SoreTicket(t []Ticket , by SortBy) {
	sort.Sort(TicketWrapper{t,by})
}
type TicketHistory struct {
	Id         int    `gorm:"primaryKey;column:id;type:int;not null" json:"id,omitempty"`
	TicketId   string `gorm:"column:ticket_id;type:varchar;size:255;not null" json:"ticket_id,omitempty"`
	Username   string `gorm:"column:username;type:varchar;size:255;not null" json:"username,omitempty"`
	CreateTime int64  `gorm:"column:create_time;type:bigint" json:"create_time,omitempty"`
	Status     string `gorm:"column:status;type:varchar;size:255;not null" json:"status,omitempty"`
	TicketJson string `gorm:"primaryKey;column:ticket_json;type:text;ticket_json;not null" json:"ticket_json,omitempty"`
	ChangeTime int64  `gorm:"column:change_time;type:bigint" json:"change_time,omitempty"`
}

type NewTikect struct {
	DiamondCutting              bool             `json:"DiamondCutting,omitempty"`
	LaserCutting                bool             `json:"LaserCutting,omitempty"`
	ChipSizeDesign              bool             `json:"ChipSizeDesign,omitempty"`
	ChipsNumber                 bool             `json:"ChipsNumber,omitempty"`
	ExposureMap                 bool             `json:"ExposureMap,omitempty"`
	ExposureParameters          bool             `json:"ExposureParameters,omitempty"`
	ExposureUnitsNumber         bool             `json:"ExposureUnitsNumber,omitempty"`
	ListChipCount               bool             `json:"ListChipCount,omitempty"`
	MassProductionPieceAssembly bool             `json:"MassProductionPieceAssembly,omitempty"`
	MpwDesign                   bool             `json:"MpwDesign,omitempty"`
	OtherIndustries             bool             `json:"OtherIndustries,omitempty"`
	OtherRequirements           string           `json:"OtherRequirements,omitempty"`
	WaferInvalidWidth           string           `json:"WaferInvalidWidth,omitempty"`
	ExposureXSpacing            string           `json:"ExposureXSpacing,omitempty"`
	ExposureYSpacing            string           `json:"ExposureYSpacing,omitempty"`
	LaserCuttingWidth           string           `json:"LaserCuttingWidth,omitempty"`
	GrooveWidth                 string           `json:"GrooveWidth,omitempty"`
	MaximumExposureRange        string           `json:"MaximumExposureRange,omitempty"`
	WaferInch                   string           `json:"WaferInch,omitempty"`
	WaferInvalidWidt            string           `json:"WaferInvalidWidt,omitempty"`
	Attributes                  []Attributeslist `json:"attributes,omitempty"`
}

type Attributeslist struct {
	Name     string `json:"name,omitempty"`
	ChipName string `json:"ChipName,omitempty"`
	Xsize    string `json:"Xsize,omitempty"`
	Ysize    string `json:"Ysize,omitempty"`
}

func (c NewTikect) Value() (driver.Value, error) {
	b, err := json.Marshal(c)
	return string(b), err
}

func (c *NewTikect) Scan(input interface{}) error {
	return json.Unmarshal(input.([]byte), c)
}

type Notice struct {
	Id    string `gorm:"primaryKey;column:id;type:varchar;size:255;autoIncrement;not null" json:"id,omitempty"`
	Email string `gorm:"column:email;type:varchar;size:255;not null" json:"email,omitempty"`
}


type Verifiy struct {
	Username         string `gorm:"column:username;type:varchar;size:255;not null" json:"username,omitempty"`
	Code             string `gorm:"column:code;type:varchar;size:255;not null" json:"code,omitempty"`
	CreateTime       int64  `gorm:"column:create_time;type:bigint" json:"create_time,omitempty"`
}

type User struct {
	Id               string `gorm:"primaryKey;column:id;type:varchar;size:255;autoIncrement;not null" json:"id,omitempty"`
	Name 			 string `gorm:"column:name;type:varchar;size:255;not null" json:"name,omitempty"`
	Username         string `gorm:"column:username;type:varchar;size:255;not null" json:"username,omitempty"`
	Mobile           string `gorm:"column:mobile;type:varchar;size:255;not null" json:"mobile,omitempty"`
	Level            string `gorm:"column:level;type:varchar;size:255" json:"level,omitempty"`
	Password         string `gorm:"column:password;type:varchar;size:255" json:"password,omitempty"`
	Count            int    `gorm:"column:count;type:int;not null" json:"count,omitempty"`
	CountTime        int64  `gorm:"column:count_time;type:bigint" json:"count_time,omitempty"`
	CountInvalidTime int64  `gorm:"column:count_invalid_time;type:bigint" json:"count_invalid_time,omitempty"`
	Amount           int64  `gorm:"column:amount;type:bigint" json:"amount,omitempty"`
	BillAmount       int64  `gorm:"column:billAmount;type:bigint" json:"billAmount,omitempty"`
	Role             string `gorm:"column:role;type:varchar;size:255;null" json:"role,omitempty"`
	Token            string `gorm:"column:token;type:varchar;size:255;not null" json:"token,omitempty"`
	ToeknTime        int64  `gorm:"column:toekn_time;type:bigint;not null" json:"toekn_time"`
	CreateTime       int64  `gorm:"column:create_time;type:bigint" json:"create_time,omitempty"`
}

func NewBiz(i Biz_interface, log *log.Logger) Biz {
	return Biz{mydb: i, log: log}
}

type Bill struct {
	Id                 string `gorm:"primaryKey;column:id;type:varchar;size:255;autoIncrement;not null" json:"id,omitempty"`
	BillHeadType       string `gorm:"column:billHeadType;type:varchar;size:255;not null" json:"billHeadType,omitempty"`
	BillType           string `gorm:"column:billType;type:varchar;size:255;not null" json:"billType,omitempty"`
	BillHead           string `gorm:"column:billHead;type:varchar;size:255;not null" json:"billHead,omitempty"`
	BillIdentifier     string `gorm:"column:billIdentifier;type:varchar;size:255;not null" json:"billIdentifier,omitempty"`
	BillAccountBank    string `gorm:"column:billAccountBank;type:varchar;size:255;not null" json:"billAccountBank,omitempty"`
	BillAccount        string `gorm:"column:billAccount;type:varchar;size:255;not null" json:"billAccount,omitempty"`
	BillCompanyAddress string `gorm:"column:billCompanyAddress;type:varchar;size:255;not null" json:"billCompanyAddress,omitempty"`
	BillCompanyPhone   string `gorm:"column:billCompanyPhone;type:varchar;size:255;not null" json:"billCompanyPhone,omitempty"`
	BillAmount         int64  `gorm:"column:billAmount;type:bigint" json:"billAmount,omitempty"`
	BillDownload       string `gorm:"column:billDownload;type:varchar;size:255;not null" json:"billDownload,omitempty"`
	Username           string `gorm:"column:username;type:varchar;size:255;not null" json:"username,omitempty"`
	BillStatus         string `gorm:"column:billStatus;type:varchar;size:255;not null" json:"billStatus,omitempty"`
}

type Biz_interface interface {
	EmailDlete(email string) error
	EmailList() []Notice
	EmailAdd(email string) error
	UpdateTicketCommentFileStatus(status string, t string, id string, role string) error
	UpdateTicket(ticket *Ticket) error
	InsterTicket(ticket *Ticket) error
	InsertUser(user *User) error
	UpdateUser(user *User) error
	DeleteUser(username string) error
	TicketGet(id string) (*Ticket, error)
	TicketList(username string, status string, dstusername string) ([]Ticket, error)
	EndTicketList(username string, dstusername string) ([]Ticket, error)
	UserOutLogin(username string) error
	UpdateToken(username string, token string, time int64) error
	GetUser(username string) (*User, error)
	TicketDialogGet(id string) (*TicketDialog, error)
	TicketDialogInster(ticketdialog *TicketDialog) error
	EndTicket(ticketend *transport.EndTicket, username string, role string) error
	Userlist() ([]User, error)
	ListBill(username string) ([]Bill, error)
	InsterBill(bill *Bill) error
	BillGet(id string) (*Bill, error)
	UpdaetBillStatus(billdownload string, id string) error
	GetVerifiy(verifiy Verifiy) (*Verifiy,error)
	IntertVerifiy(verifiy Verifiy) error
	UpdatePass(username string,password string) error
}
func (b *Biz) UpdatePass(username string,password string) error {
	return  b.mydb.UpdatePass(username,password)
}
func(b *Biz) IntertVerifiy(verifiy Verifiy) error {
	return b.mydb.IntertVerifiy(verifiy)
}

func(b *Biz) GetVerifiy(verifiy Verifiy) (*Verifiy,error) {
	return b.mydb.GetVerifiy(verifiy)
}

func(b *Biz) UpdaetBillStatus(billdownload string, id string) error {
	return b.mydb.UpdaetBillStatus(billdownload,id)
}

func (b *Biz) UpdateTicket(ticket *Ticket) error {
	return b.mydb.UpdateTicket(ticket)
}

func (b *Biz) BillGet(id string) (*Bill, error) {
	return b.mydb.BillGet(id)
}


func (b *Biz) ListBill(username string) ([]Bill, error) {
	return b.mydb.ListBill(username)
}

func (b *Biz) InsterBill(bill *Bill) error {
	return b.mydb.InsterBill(bill)
}

func (b *Biz) EmailList() []Notice {
	return b.mydb.EmailList()
}

func (b *Biz) EmailAdd(email string) error {
	return b.mydb.EmailAdd(email)
}
func (b *Biz) EmailDlete(email string) error {
	return b.mydb.EmailDlete(email)
}

func (b *Biz) DeleteUser(username string) error {
	return b.mydb.DeleteUser(username)
}

func (b *Biz) UpdateUser(user *User) error {
	return b.mydb.UpdateUser(user)
}

func (b *Biz) Userlist() ([]User, error) {
	return b.mydb.Userlist()
}

func (b *Biz) UserOutLogin(username string) error {
	return b.mydb.UserOutLogin(username)
}

func (b *Biz) UpdateTicketCommentFileStatus(status string, t string, id string, role string) error {
	return b.mydb.UpdateTicketCommentFileStatus(status, t, id, role)
}

func (b *Biz) EndTicketList(username string, dstusername string) ([]Ticket, error) {
	return b.mydb.EndTicketList(username, dstusername)
}

func (b *Biz) EndTicket(ticketend *transport.EndTicket, username string, role string) error {

	return b.mydb.EndTicket(ticketend, username, role)
}

func (b *Biz) TicketDialogGet(id string) (*TicketDialog, error) {
	return b.mydb.TicketDialogGet(id)
}

func (b *Biz) TicketDialogInster(ticketdialog *TicketDialog) error {
	return b.mydb.TicketDialogInster(ticketdialog)
}

func (b *Biz) TicketGet(id string) (*Ticket, error) {
	return b.mydb.TicketGet(id)
}

func (b *Biz) TicketList(username string, status string, dstusername string) ([]Ticket, error) {

	return b.mydb.TicketList(username, status, dstusername)

}

func (b *Biz) InsterTicket(ticket *Ticket) error {

	return b.mydb.InsterTicket(ticket)
}

func (b *Biz) UpdateToken(username string, token string, time int64) error {

	return b.mydb.UpdateToken(username, token, time)
}

func (b *Biz) GetUser(username string) (*User, error) {

	return b.mydb.GetUser(username)
}

func (b *Biz) InsertUser(user *User) error {

	return b.mydb.InsertUser(user)
}
