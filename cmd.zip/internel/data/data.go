package data

import (
	"errors"
	"log"
	"ltd_backend/internel/biz"
	"ltd_backend/internel/transport"
	"strconv"
	"time"

	"gorm.io/gorm"
)

type greeterRepo struct {
	data *Mydb
	log  *log.Logger
}

func NewGreeterRepo(data *Mydb, log *log.Logger) biz.Biz_interface {

	return &greeterRepo{
		data: data,
		log:  log,
	}
}

func (greeter *greeterRepo) TicketDialogGet(id string) (*biz.TicketDialog, error) {
	var ticketdialog biz.TicketDialog
	restult := greeter.data.Db.Where("id =? ", id).First(&ticketdialog)

	if restult.Error != nil {
		if restult.Error.Error() == "record not found" {
			return nil, nil
		}
		return nil, restult.Error
	}

	return &ticketdialog, nil

}

func (greeter *greeterRepo) EmailDlete(email string) error {
	restult := greeter.data.Db.Where("email =? ", email).Delete(&biz.Notice{})
	if restult.Error != nil {

		return restult.Error
	}
	return nil
}

func (greeter *greeterRepo) EmailList() []biz.Notice {
	var emaillist []biz.Notice
	greeter.data.Db.Find(&emaillist)
	return emaillist
}

func (greeter *greeterRepo) EmailAdd(email string) error {
	var emailobj biz.Notice
	restult := greeter.data.Db.Where("email =?", email).First(&emailobj)
	if restult.Error != nil {
		if restult.Error.Error() == "record not found" {
			print(email)
			greeter.data.Db.Save(&biz.Notice{Email: email})
		} else {
			return restult.Error
		}

	}
	return nil

}

func (greeter *greeterRepo) Userlist() ([]biz.User, error) {
	var user []biz.User
	restult := greeter.data.Db.Where("role != 'admin'").Select("id", "name", "count_invalid_time", "username", "password", "mobile", "level", "count", "count_time", "amount", "create_time").Find(&user)

	if restult.Error != nil {
		if restult.Error.Error() == "record not found" {
			return nil, nil
		}
		return nil, restult.Error
	}

	return user, nil
}

func (greeter *greeterRepo) UpdateTicketCommentFileStatus(status string, t string, id string, role string) error {
	var restult *gorm.DB

	if t == "file" {
		if role == "admin" {
			if status == "0" {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"user_file_status": status})

			} else {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"engineer_file_status": status})

			}

		} else {
			if status == "0" {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"engineer_file_status": status})

			} else {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"user_file_status": status})

			}

		}

	} else {

		if role == "admin" {
			if status == "0" {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"user_comment_status": status})

			} else {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"engineer_comment_status": status})

			}
		} else {
			if status == "0" {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"engineer_comment_status": status})

			} else {
				restult = greeter.data.Db.Table("tickets").Where("id =? ", id).Updates(map[string]interface{}{"user_comment_status": status})

			}

		}
	}

	if restult.Error != nil {
		return restult.Error
	}

	return nil
}

func (greeter *greeterRepo) UpdateTicket(ticket *biz.Ticket) error {
	srcticket, _ := greeter.TicketGet(ticket.Id)
	if srcticket != nil {

		now := time.Now().UnixMilli()

		greeter.data.Db.Save(&biz.TicketHistory{Status: srcticket.Status, TicketJson: srcticket.TicketJson, TicketId: srcticket.Id, Username: srcticket.Username, ChangeTime: now, CreateTime: srcticket.CreateTime})
		ticket.ChangeHistory = strconv.FormatInt(now, 10) + "," + ticket.ChangeHistory
		if restult := greeter.data.Db.Table("tickets").Where("id =? ", ticket.Id).Updates(map[string]interface{}{"ticket_json": ticket.TicketJson}); restult.Error != nil {

			return restult.Error

		}

		return nil

	}

	return errors.New("Ticket not exists!")

}

func (greeter *greeterRepo) EndTicket(ticketend *transport.EndTicket, username string, role string) error {
	var restult *gorm.DB
	if role == "guest" {
		restult = greeter.data.Db.Table("tickets").Where("id =? AND username =?", ticketend.Id, username).Updates(map[string]interface{}{"score": ticketend.Score, "comment": ticketend.Comment, "status": "2", "end_time": time.Now().UnixMilli()})

	} else {
		if ticketend.Comment == "由工程师结单" {

			restult = greeter.data.Db.Table("tickets").Where("id =? AND username =?", ticketend.Id, username).Updates(map[string]interface{}{"score": ticketend.Score, "comment": ticketend.Comment, "status": "2", "end_time": time.Now().UnixMilli()})

		} else {
			restult = greeter.data.Db.Table("tickets").Where("id =? AND username =?", ticketend.Id, username).Updates(map[string]interface{}{"status": "1"})

		}

	}
	if restult.Error != nil {
		return restult.Error
	}

	return nil
}

func (greeter *greeterRepo) TicketDialogInster(ticketdialog *biz.TicketDialog) error {
	t, err := greeter.TicketDialogGet(ticketdialog.Id)
	if err == nil {
		if t == nil {
			greeter.data.Db.Save(ticketdialog)
			return nil
		}
	}

	restult := greeter.data.Db.Table("ticket_dialogs").Where("id =?", ticketdialog.Id).Updates(map[string]interface{}{"dialog": ticketdialog.Dialog})
	if restult.Error != nil {
		return restult.Error
	}

	return nil
}


func (greeter *greeterRepo) UpdateToken(username string, token string, time int64) error {
	restult := greeter.data.Db.Table("users").Where("username =?", username).Updates(map[string]interface{}{"token": token, "toekn_time": time})
	if restult.Error != nil {

		return restult.Error
	}
	return nil
}


func (greeter *greeterRepo) UserOutLogin(username string) error {
	restult := greeter.data.Db.Table("users").Where("username =?", username).Updates(map[string]interface{}{"token": "", "toekn_time": 0})
	if restult.Error != nil {

		return restult.Error
	}
	return nil
}


func (greeter *greeterRepo) GetUser(username string) (*biz.User, error) {
	var user biz.User
	restult := greeter.data.Db.Where("username =? ", username).First(&user)

	if restult.Error != nil {
		if restult.Error.Error() == "record not found" {
			return nil, nil
		}
		return nil, restult.Error
	}

	return &user, nil
}

func (greeter *greeterRepo) GetVerifiy(verifiy biz.Verifiy) (*biz.Verifiy,error) {
	var v biz.Verifiy
	if restult := greeter.data.Db.Where("username =?", verifiy.Username).First(&v); restult .Error != nil {

		return nil,restult.Error
	}
	return &v,nil
}


func (greeter *greeterRepo) IntertVerifiy(verifiy biz.Verifiy) error {
	var restult *gorm.DB
	v, _ := greeter.GetVerifiy(verifiy)
	if v == nil {
		restult = greeter.data.Db.Create(&verifiy)

	}else {
		restult =  greeter.data.Db.Save(&verifiy)
	}
	if restult.Error != nil {
		return restult.Error
	}
	return nil 
}


func (greeter *greeterRepo) UpdaetBillStatus(billdownload string, id string) error {

	restult := greeter.data.Db.Table("bills").Where("id =?", id).Updates(map[string]interface{}{"billStatus":"1","billDownload": billdownload})
	if restult.Error != nil {

		return restult.Error
	}
	return nil
}


func (greeter *greeterRepo) ListBill(username string) ([]biz.Bill, error) {
	var bill []biz.Bill
	var restult *gorm.DB

	user, _ := greeter.GetUser(username)
	if user.Role == "admin" {
		restult = greeter.data.Db.Find(&bill)

	} else {
		restult = greeter.data.Db.Where("username =?", username).Find(&bill)

	}

	if restult.Error != nil {
		if restult.Error.Error() == "record not found" {
			return nil, nil
		}
		return nil, restult.Error
	}
	return bill, nil
}

func (greeter *greeterRepo) InsterBill(bill *biz.Bill) error {

	var restult *gorm.DB
	restult = greeter.data.Db.Save(bill)
	if restult.Error != nil {
		return restult.Error
	}
	user, _ := greeter.GetUser(bill.Username)
	restult = greeter.data.Db.Table("users").Where("id =?", user.Id).Updates(map[string]interface{}{"billAmount": user.Amount - bill.BillAmount})
	if restult.Error != nil {
		return restult.Error
	}
	return nil
}

func (greeter *greeterRepo) InsterTicket(ticket *biz.Ticket) error {
	greeter.data.Db.Save(ticket)
	return nil
}

func (greeter *greeterRepo) BillGet(id string) (*biz.Bill, error) {
	var bill biz.Bill
	restult := greeter.data.Db.Where("id =? ", id).First(&bill)

	if restult.Error != nil {

		return nil, restult.Error
	}

	return &bill, nil
}

func (greeter *greeterRepo) TicketGet(id string) (*biz.Ticket, error) {
	var ticket biz.Ticket
	restult := greeter.data.Db.Where("id =? ", id).First(&ticket)

	if restult.Error != nil {

		return nil, restult.Error
	}

	return &ticket, nil
}

func (greeter *greeterRepo) EndTicketList(username string, dstusername string) ([]biz.Ticket, error) {
	var ticketlist []biz.Ticket

	user, err := greeter.GetUser(username)
	if err != nil {
		return nil, err
	}

	if user.Role == "guest" {

		greeter.data.Db.Select("id", "username", "create_time", "status", "score").Where("username =? AND status = 2", username).Find(&ticketlist)
		return ticketlist, nil
	} else {

		if dstusername == "" {

			greeter.data.Db.Select("id", "username", "create_time", "status", "score").Where("status = 2 ").Find(&ticketlist)

		} else {

			greeter.data.Db.Select("id", "username", "create_time", "status", "score").Where("username =? AND status =2 ", dstusername).Find(&ticketlist)

		}

		return ticketlist, nil

	}

}

func (greeter *greeterRepo) TicketList(username string, status string, dstusername string) ([]biz.Ticket, error) {
	var ticketlist []biz.Ticket

	user, err := greeter.GetUser(username)
	if err != nil {
		return nil, err
	}

	if user.Role == "guest" {
		greeter.data.Db.Select("id", "username", "create_time", "status", "score", "end_time", "user_comment_status", "engineer_comment_status", "user_file_status", "engineer_file_status").Where("username =? ", username).Find(&ticketlist)
		return ticketlist, nil
	} else {

		if status == "" && dstusername == "" {
			greeter.data.Db.Select("id", "username", "create_time", "status", "score", "user_comment_status", "engineer_comment_status", "user_file_status", "engineer_file_status").Where("status = 0 OR status = 1").Find(&ticketlist)

		} else if dstusername != "" && status == "" {
			greeter.data.Db.Select("id", "username", "create_time", "status", "score", "end_time", "user_comment_status", "engineer_comment_status", "user_file_status", "engineer_file_status").Where("username =? AND status != 2", dstusername).Find(&ticketlist)

		} else if status != "" && dstusername == "" {
			greeter.data.Db.Select("id", "username", "create_time", "status", "score", "end_time", "user_comment_status", "engineer_comment_status", "user_file_status", "engineer_file_status").Where("status =? ", status).Find(&ticketlist)

		} else {
			greeter.data.Db.Select("id", "username", "create_time", "status", "score", "end_time", "user_comment_status", "engineer_comment_status", "user_file_status", "engineer_file_status").Where("username =? AND status =?", dstusername, status).Find(&ticketlist)

		}
		return ticketlist, nil

	}

}

func (greeter *greeterRepo) InsertUser(user *biz.User) error {
	result, err := greeter.GetUser(user.Username)
	if err != nil {
		return err
	}

	if result != nil {

		return errors.New(result.Username + "  already exists!")
	}

	greeter.data.Db.Save(&user)
	return nil
}

func (greeter *greeterRepo) DeleteUser(username string) error {

	restult := greeter.data.Db.Where("username = ?", username).Delete(&biz.User{})
	if restult.Error != nil {

		return restult.Error
	}
	return nil
}


func (greeter *greeterRepo) UpdatePass(username string,password string) error {
	restult := greeter.data.Db.Table("users").Where("username =?", username).Updates(map[string]interface{}{"password": password})

	if restult.Error != nil {

		return restult.Error
	}
	return nil
}

func (greeter *greeterRepo) UpdateUser(user *biz.User) error {
	srcuser, _ := greeter.GetUser(user.Username)
	restult := greeter.data.Db.Table("users").Where("username =?", user.Username).Updates(map[string]interface{}{"count_time": user.CountTime, "count": user.Count, "amount": user.Amount + srcuser.Amount, "billAmount": user.BillAmount + srcuser.Amount, "mobile": user.Mobile, "level": user.Level})

	if restult.Error != nil {

		return restult.Error
	}
	return nil
}
