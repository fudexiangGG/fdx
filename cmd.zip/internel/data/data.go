package data

import (
	"errors"
	"fmt"
	"log"
	"ltd_backend/internel/biz"
)

type greeterRepo struct {
	data *Mydb
	log  *log.Logger
}

// NewGreeterRepo .
func NewGreeterRepo(data *Mydb, log *log.Logger) biz.Biz_interface {

	return &greeterRepo{
		data: data,
		log:  log,
	}
}

func(greeter *greeterRepo) TicketDialogGet(id string) (*biz.TicketDialog,error) {
	var ticketdialog biz.TicketDialog
	restult := greeter.data.Db.Where("id =? ", id).First(&ticketdialog)
	fmt.Printf("%#v\n",ticketdialog)
	if restult.Error != nil {

		return nil, restult.Error
	}

	return &ticketdialog, nil

}

func(greeter *greeterRepo) TicketDialogInster(ticketdialog *biz.TicketDialog) error {

	if t, err := greeter.TicketDialogGet(ticketdialog.Id); err == nil {
		if t == nil {
			greeter.data.Db.Save(ticketdialog)
			return nil
		}
	}

   restult := greeter.data.Db.Table("ticket_dialogs").Where("id =?",ticketdialog.Id).Updates(map[string]interface{}{"dialog": ticketdialog.Dialog})
		if restult.Error != nil {
		return restult.Error
		}

		return nil
}


func(greeter *greeterRepo) UpdateToken(username string,token string,time int64) error {
	 restult := greeter.data.Db.Table("users").Where("username =?",username).Updates(map[string]interface{}{"token": token, "toekn_time": time })
	 if restult.Error != nil {
		
		return restult.Error
	 }
	return nil
}


func(greeter *greeterRepo) GetUser(username string) (*biz.User, error) {
	var user biz.User
	restult := greeter.data.Db.Where("username =? ", username).First(&user)

	if restult.Error != nil {
		if restult.Error.Error() == "record not found" {
			return nil, nil
		}
		return nil, restult.Error
	}

	return &user, nil
}

func (greeter *greeterRepo) InsterTicket(ticket *biz.Ticket) error {
	greeter.data.Db.Save(ticket)
	return nil
}

func (greeter *greeterRepo) TicketGet(id string) (*biz.Ticket,error) {
	var ticket biz.Ticket
	restult := greeter.data.Db.Where("id =? ", id).First(&ticket)

	if restult.Error != nil {

		return nil, restult.Error
	}

	return &ticket, nil
}

func (greeter *greeterRepo) TicketList(username string,status string)  ([]biz.Ticket,error) {
	var ticketlist []biz.Ticket


	user,err := greeter.GetUser(username)
	if err != nil {
		return nil,err
	}
	if user.Role == "guest" {
		greeter.data.Db.Select("id","username","create_time","status").Where("username =? ", username).Find(&ticketlist)
		return ticketlist,nil
	}else
	{
		switch status {
		case "0":
			greeter.data.Db.Select("id","username","create_time","status").Where("status =? ", status).Find(&ticketlist)
			case "1":
				greeter.data.Db.Select("id","username","create_time","status").Where("status =? ", status).Find(&ticketlist)

		default:
			greeter.data.Db.Select("id","username","create_time","status").Where("status =? ", status).Find(&ticketlist)


		}
		return ticketlist,nil

		}


}


func (greeter *greeterRepo) InsertUser(user *biz.User) error {
	result, err := greeter.GetUser(user.Username)
	if err != nil {
		return err
	}

	if result != nil {

		return errors.New(result.Username + "  already exists!")
	}

	greeter.data.Db.Save(&user)
	return nil
}
