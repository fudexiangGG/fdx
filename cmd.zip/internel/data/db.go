package data

import (
	"fmt"
	"log"
	"ltd_backend/internel/conf"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)


type Mydb struct {
	Db *gorm.DB
	
}

func NewMydb( config *conf.Mysql ) *Mydb {

	dsn := fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=True&loc=Local",config.User,config.Pass,config.Host,config.Db)
 	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		log.Panic(err.Error())
	}
	
	return &Mydb{Db: db}
}