package ltdmail


import (
"crypto/tls"
"fmt"
"log"
"net"
"net/smtp"
)


// Test465  for port 465
func EmailSend(username string,code string) error {
	host := "smtp.qiye.aliyun.com"
	port := 465
	//控制台创建的发信地址
	email := "notification@lawdcl.com"
	//控制台设置的SMTP密码
	password := "t7IwQ5Hdjw"
	toEmail := username
	header := make(map[string]string)
	header["From"] = "Ltd " + "<" + email + ">"
	header["To"] = toEmail
	header["Subject"] = "Ltd Verification Code"
	//html格式邮件
	header["Content-Type"] = "text/html; charset=UTF-8"
	body := fmt.Sprintf("<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"utf-8\">\n<title>hello world</title>\n</head>\n<body>\n<h1>Dear %s:</h1>\n    <p>验证码: %s,有效期5分钟!</p>\n</body>\n</html>",username,code)

	message := ""
	for k, v := range header {
		message += fmt.Sprintf("%s: %s\r\n", k, v)
	}
	message += "\r\n" + body
	auth := smtp.PlainAuth(
		"",
		email,
		password,
		host,
	)
	err := SendMailWithTLS(
		fmt.Sprintf("%s:%d", host, port),
		auth,
		email,
		[]string{toEmail},
		[]byte(message),
	)
	if err != nil {
		log.Println("Send email error:", err)
	}
	return err
}

// Dial return a smtp client
func Dial(addr string) (*smtp.Client, error) {
	conn, err := tls.Dial("tcp", addr, nil)
	if err != nil {
		log.Println("tls.Dial Error:", err)
		return nil, err
	}

	host, _, _ := net.SplitHostPort(addr)
	return smtp.NewClient(conn, host)
}

// SendMailWithTLS send email with tls
func SendMailWithTLS(addr string, auth smtp.Auth, from string,
	to []string, msg []byte) (err error) {
	//create smtp client
	c, err := Dial(addr)
	if err != nil {
		log.Println("Create smtp client error:", err)
		return err
	}
	defer c.Close()
	if auth != nil {
		if ok, _ := c.Extension("AUTH"); ok {
			if err = c.Auth(auth); err != nil {
				log.Println("Error during AUTH", err)
				return err
			}
		}
	}
	if err = c.Mail(from); err != nil {
		return err
	}
	for _, addr := range to {
		if err = c.Rcpt(addr); err != nil {
			return err
		}
	}
	w, err := c.Data()
	if err != nil {
		return err
	}
	_, err = w.Write(msg)
	if err != nil {
		return err
	}
	err = w.Close()
	if err != nil {
		return err
	}
	return c.Quit()
}