package service

import (
	"crypto/md5"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"ltd_backend/internel/biz"
	"ltd_backend/internel/transport"
	"net/http"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
)

type Service struct {
	biz biz.Biz
	log *log.Logger
}

func NewSercice_interface(biz biz.Biz, log *log.Logger) *Service {

	return &Service{
		biz: biz,
		log: log,
	}

}

func md5crypto(v string) string {
	d := []byte(v)
	m := md5.New()
	m.Write(d)
	return hex.EncodeToString(m.Sum(nil))
}

func GetToken() (string, int64) {

	b := make([]byte, 16)
	rand.Read(b)
	now := time.Now().Unix()
	return fmt.Sprintf("%x", b), now
}

func (s *Service) Login(c *gin.Context) {
	var user transport.User

	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "loginType": "account", "errorCode": "5551"})
		return
	}

	srcUser, err := s.biz.GetUser(user.Username)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "loginType": "account", "errorCode": "5551"})
		return
	}

	if md5crypto(user.Password) != srcUser.Password {

		c.JSON(http.StatusOK, gin.H{"errorMessage": "密码不正确!", "success": true, "data": "密码不正确!", "loginType": "account", "errorCode": "5551", "status": "密码不正确!"})
		return
	}
	token, time := GetToken()

	if err := s.biz.UpdateToken(user.Username, token, time); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "Token fail!", "loginType": "account", "errorCode": "5551"})
		return
	}

	c.SetCookie("ltd_token", user.Username+":"+token, 28800, "/", "127.0.0.1", false, true)
	srcUser.Password = ""
	c.JSON(http.StatusOK, gin.H{"success": true, "data": "", "loginType": "account", "status": "ok"})

}

func (s *Service) GetCookieUser(c *gin.Context) (*biz.User, error) {
	cookie, err := c.Cookie("ltd_token")
	if err != nil {
		return nil, err
	}
	co := strings.Split(cookie, ":")
	return s.biz.GetUser(co[0])

}

func (s *Service) TicketDialogGet(c *gin.Context) {
	id := c.Query("id")

	dialog, err := s.biz.TicketDialogGet(id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})

	}

	if dialog == nil {
		c.JSON(http.StatusOK, gin.H{ "success": true, "data": ""})
	}

	req,err := decodeDialog(dialog.Dialog)

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})

	}


	c.JSON(http.StatusOK, req)

}
func (s *Service) CurrentUser(c *gin.Context) {
	user, err := s.GetCookieUser(c)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})

	}

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return
	}
	user.Password = " "
	c.JSON(http.StatusOK, gin.H{"success": true, "data": user, "username": user.Username, "mobile": user.Mobile, "level": user.Level, "role": user.Role, "id": user.Id})

}

func commonencode(tikect interface{}) ([]byte, error) {
	t, err := json.Marshal(tikect)
	if err != nil {
		return nil, err
	}
	return t, nil
}

func decodeDialog(t string) (transport.DialogReq, error) {
	var dialog transport.DialogReq
	err := json.Unmarshal([]byte(t), &dialog)
	if err != nil {
		println(err.Error())
		return transport.DialogReq{}, err
	}
	return dialog, nil
}

func decodeTicket(t string) (biz.NewTikect, error) {
	var ticket biz.NewTikect
	err := json.Unmarshal([]byte(t), &ticket)
	if err != nil {
		println(err.Error())
		return biz.NewTikect{}, err
	}
	return ticket, nil
}

func (s *Service) TicketGet(c *gin.Context) {
	id := c.Query("id")
	ticket, err := s.biz.TicketGet(id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return

	}
	println(ticket.TicketJson)
	t, err := decodeTicket(ticket.TicketJson)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return

	}
	c.JSON(http.StatusOK, t)

}

func (s *Service) TicketList(c *gin.Context) {
	status := c.Query("status")
	user, err := s.GetCookieUser(c)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}
	ticketlist, err := s.biz.TicketList(user.Username, status)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": ticketlist})
}

func (s *Service) InsterDialog(c *gin.Context) {
	var dialog transport.DialogReq

	if err := c.ShouldBindJSON(&dialog); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": false, "data": "", "errorCode": "5552"})
		return
	}

	data, _ := commonencode(dialog)
	if err := s.biz.TicketDialogInster(&biz.TicketDialog{Id: dialog.Data[0].Id,Dialog: string(data)}); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": false, "data": "", "errorCode": "5552"})

	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "创建成功"})
}

func (s *Service) InsterTicket(c *gin.Context) {
	var ticket biz.Ticket
	var newticket biz.NewTikect
	user, err := s.GetCookieUser(c)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}

	if err := c.ShouldBindJSON(&newticket); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": false, "data": "", "errorCode": "5552"})
		return
	}

	now := time.Now().UnixMilli()
	t, err := commonencode(&newticket)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5552"})
	}
	ticket.TicketJson = string(t)
	ticket.Username = user.Username
	ticket.CreateTime = now
	ticket.Status = "0"

	if err := s.biz.InsterTicket(&ticket); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5552"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "创建成功"})

}

func (s *Service) InsertUserEndpoint(c *gin.Context) {
	var user transport.UserRegister

	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5552"})
		return
	}

	now := time.Now().Unix()
	if err := s.biz.InsertUser(&biz.User{Username: user.Username, Password: md5crypto(user.Password), Mobile: user.Mobile, CreateTime: now,
		Level: "0", Count: 0, CountTime: 0, Amount: 0, Role: "guest", Token: " ", ToeknTime: 0}); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "success", "status": "ok"})
}

func (s *Service) CheckLogin() gin.HandlerFunc {

	return func(c *gin.Context) {
		cookie, err := c.Cookie("ltd_token")

		if err != nil {
			c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}

		co := strings.Split(cookie, ":")

		user, err := s.biz.GetUser(co[0])
		if err != nil {
			c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}
		if user.Token != co[1] {
			c.JSON(http.StatusOK, gin.H{"errorMessage": "Token fail!", "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}

	}
}
