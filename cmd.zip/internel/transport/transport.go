package transport

type LoginRes struct {
	Status string `json:"status,omitempty"`
}
type User struct {
	Username string `form:"username" json:"username" xml:"username"  binding:"required"`
	Password string `form:"password" json:"password" xml:"password" binding:"required"`
}


type AdminUser struct {
	Name string `json:"name,omitempty"`
	Username string `json:"username,omitempty"`
	Password string `json:"password,omitempty"`
	Mobile string `json:"mobile,omitempty"`
	Count int `json:"count,omitempty"`
	Amount int64 `json:"amount,omitempty"`
	CountTime int64 `json:"count_time,omitempty"`
}
type UserForgetPass struct {
	Username string `form:"username" json:"username" xml:"username"  binding:"required"`
	Password string `form:"password" json:"password" xml:"password" binding:"required"`
	Captcha  string `form:"captcha" json:"captcha" xml:"captcha" binding:"required"`
}

type UserRegister struct {
	Name string `json:"name,omitempty"`
	Username string `form:"username" json:"username" xml:"username"  binding:"required"`
	Password string `form:"password" json:"password" xml:"password" binding:"required"`
	Mobile   string `form:"mobile" json:"mobile" xml:"mobile" binding:"required"`
	Captcha  string `form:"captcha" json:"captcha" xml:"captcha" binding:"required"`
}

type DialogReq struct {
	Data []Dialog `json:"dialog,omitempty"`
}

type Dialog struct {
	User string `json:"user,omitempty"`
	Data string `json:"data,omitempty" binding:"required"`
	Id   string `json:"id,omitempty"`
}

type FileList struct {
	Name   string `json:"name,omitempty"`
	Stutus string `json:"stutus,omitempty"`
	Url    string `json:"url,omitempty"`
}

type EndTicket struct {
	Id      string `json:"id,omitempty"`
	Score   int    `json:"score,omitempty"`
	Comment string `json:"comments,omitempty"`
}
