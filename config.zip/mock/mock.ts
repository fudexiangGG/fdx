import { Request, Response } from 'express';

export default {
    'POST /api/checklogin': (req: Request, res: Response, u: string) => {
      res.send({
        success: true,
      });
    },
  };