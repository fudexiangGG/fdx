export default {
  'app.pwa.offline': 'شما اکنون آفلاین هستید',
  'app.pwa.serviceworker.updated': 'مطالب جدید در دسترس است',
  'app.pwa.serviceworker.updated.hint':
    'لطفاً برای بارگیری مجدد صفحه فعلی ، دکمه "تازه سازی" را فشار دهید',
  'app.pwa.serviceworker.updated.ok': 'تازه سازی',
};
