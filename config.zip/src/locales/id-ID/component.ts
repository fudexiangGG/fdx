export default {
  'component.tagSelect.expand': 'Perluas',
  'component.tagSelect.collapse': 'Lipat',
  'component.tagSelect.all': 'Semua',
};
