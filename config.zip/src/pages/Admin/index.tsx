import {AddUser, userdelete,userlist,UpdateUser } from '@/services/ant-design-pro/api';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns,  } from '@ant-design/pro-components';
import {
 
  ProFormDigit,
  ModalForm,
  ProFormText,
  PageContainer,
  ProTable,
} from '@ant-design/pro-components';
import { FormattedMessage, useIntl ,useModel} from '@umijs/max';
import { Button,Input, message,Form, Popconfirm, } from 'antd';
import React, { useRef, useState } from 'react';


/**
 * @en-US Add node
 * @zh-CN 添加节点
 * @param fields
 */
const handleAddUser = async (fields: API.AddUser) => {

  const hide = message.loading('正在添加');
  try {
    
    await AddUser({ ...fields });
    hide();
    message.success('Successfully!');
    return true;
  } catch (error) {
    hide();
    message.error('Failed!');
    return false;
  }
};



const confirm = (e: React.MouseEvent<HTMLElement>) => {
  console.log(e);
  message.success('Click on Yes');
};

const cancel = (e: React.MouseEvent<HTMLElement>) => {
  console.log(e);
  message.error('Click on No');
};


const handleDleteUser = async (fields: string |undefined) => {

  const hide = message.loading('正在删除');
  try {
    
    await userdelete({username:fields});
    hide();
    message.success('Successfully!');
    return true;
  } catch (error) {
    hide();
    message.error('Failed!');
    return false;
  }
};


/**
 * @en-US Update node
 * @zh-CN 更新节点
 *
 * @param fields
 */
const handleUpdate = async (fields: API.AddUser) => {
  const hide = message.loading('正在修改');
  try {
    await UpdateUser({...fields});
    hide();

    message.success('Configuration is successful');
    return true;
  } catch (error) {
    hide();
    message.error('Configuration failed, please try again!');
    return false;
  }
};


/**
 *  Delete node
 * @zh-CN 删除节点
 *
 * @param selectedRows
 */
const handleRemove = async () => {
  
};


const UserList: React.FC = () => {
  /**
   * @en-US The pop-up window of the distribution update window
   * @zh-CN 分布更新窗口的弹窗
   * */
  const [CreateUserModalOpen,handleCreateUserModalOpen] = useState<boolean>(false);
  const [updateModalOpen, handleUpdateModalOpen] = useState<boolean>(false);
  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<API.UserList>();
  const [selectedRowsState, setSelectedRows] = useState<API.UserList[]>([]);

  /**
   * @en-US International configuration
   * @zh-CN 国际化配置
   * */
  const intl = useIntl();
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const columns: ProColumns<API.UserList>[] = [
    {
      title: "ID",
      dataIndex: 'id',
      search: false,
    },
  
    {
      title: "手机号",
      dataIndex: 'mobile',
      search: false,
      valueType:"text"
    },
    {
      title: "邮箱",
      dataIndex: 'username',
      search: false,
      valueType:"text"
    },
    {
      title: "等级",
      dataIndex: 'level',
      hideInForm: true,
      search: false,
      valueEnum: {
       
      3: {
            text: "年",
          },
      2: {
            text: "季",
          },
      1: {
            text: "月",
          },
          0: {
            text: "日",
          }
      },
    },
    {
      title: "次数",
      dataIndex: 'count',
      search: false,
      valueType:"text"
    },
    {
      title: "次数时长(月)",
      dataIndex: 'count_time',
      search: false,
      valueType:"text"
    },
    {
      title: "充值总金额",
      dataIndex: 'amount',
      search: false,
      valueType:"money"
    },
    {
      title: "创建时间",
      
      sorter: false,
      search: false,
      dataIndex: 'create_time',
      valueType: 'dateTime',

    },
    {
      title: <FormattedMessage id="pages.searchTable.titleOption" defaultMessage="Operating" />,
      dataIndex: 'option',
      valueType: 'option',
   
      render: (_, record) => [

      
        <Button key="updateuser"  onClick={() => {
          handleUpdateModalOpen(true);
          setCurrentRow(record)
         
       }}>
         修改
        </Button>,
        
        <Popconfirm
          title="Delete the user"
          description="Are you sure to delete this user?"
          onConfirm={() => {
            handleDleteUser(record.username)
            actionRef.current?.reload()
  
           }}
          okText="Yes"
          cancelText="No"
        >
         <Button danger key="deleteuser" >
         删除
       </Button>
       </Popconfirm>
       
      ],
    },
  ];

  return (
    <PageContainer>

      <ProTable<API.UserList, API.PageParams>
        headerTitle=''
        actionRef={actionRef}
        rowKey="id"
        search={false}
        toolBarRender={() => [
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              handleCreateUserModalOpen(true);
            }}
          >
            <PlusOutlined /> <FormattedMessage id="pages.searchTable.user" defaultMessage="用户" />
          </Button>,
        ]}
        request={userlist}
        columns={columns}
        rowSelection={{
          onChange: (_, selectedRows) => {
            setSelectedRows(selectedRows);
          },
        }}
      />

  
        <ModalForm
            initialValues={{username:currentRow?.username,
              mobile:currentRow?.mobile,
              amount:currentRow?.amount,
              count:currentRow?.count,
              count_time: currentRow?.count_time
              
            }}
            width={640}
            modalProps={{
              destroyOnClose: true,
              style:{ padding: '32px 40px 48px' }
            }}
            title="用户修改"
            open={updateModalOpen}
            onOpenChange={handleUpdateModalOpen}

            onFinish={ async (value)=> {
              
              const success = await handleUpdate(value as API.AddUser);
              if (success) {
                handleUpdateModalOpen(false);
                if (actionRef.current) {
                  actionRef.current.reload();
                }
              }
            }}
          >
       
            <ProFormText
            disabled
                name="username"
                label="用户名"
                placeholder="请输入邮箱"
                rules={[
                  
                    {
                      required: true,
                      message: "请输入邮箱",
                    },
                    {
                      pattern: /^[a-zA-Z0-9]+([-_.][A-Za-zd]+)*@([a-zA-Z0-9]+[-.])+[A-Za-zd]{2,5}$/,
                      message: "邮箱格式错误",
                    },
                  
                ]}
              />
            
        <Form.Item   required name="mobile" label="手机号:">
            <Input    />
        </Form.Item>
        
        <ProFormDigit
            label="次数"
            name="count"
          
          
          />

        <ProFormDigit
            label="充值金额"
            name="amount"
          
            
          />
            <ProFormDigit
            label="时长"
            name="count_time"
          addonAfter="月"
            
          />
          
      </ModalForm>


      <ModalForm
            width={640}
            modalProps={{
              destroyOnClose: true,
              style:{ padding: '32px 40px 48px' }
            }}
            title="添加用户"
            open={CreateUserModalOpen}
            onOpenChange={handleCreateUserModalOpen}

            onFinish={ async (value)=> {
              
              const success = await handleAddUser(value as API.AddUser);
              if (success) {
                handleCreateUserModalOpen(false);
                if (actionRef.current) {
                  actionRef.current.reload();
                }
              }
            }}
          >
       
            <ProFormText
                name="username"
                label="用户名"
                placeholder="请输入邮箱"
                rules={[
                  
                    {
                      required: true,
                      message: "请输入邮箱",
                    },
                    {
                      pattern: /^[a-zA-Z0-9]+([-_.][A-Za-zd]+)*@([a-zA-Z0-9]+[-.])+[A-Za-zd]{2,5}$/,
                      message: "邮箱格式错误",
                    },
                  
                ]}
              />
              <ProFormText.Password
                name="password"
                label="密码"
                rules={[
                  {
                    
                    required: true,
                    message: (
                      <FormattedMessage
                        id="pages.login.password.required"
                        defaultMessage="请输入密码！"
                      />
                    ),
                  },
                ]}
              />
        
        <Form.Item   required name="mobile" label="手机号:">
            <Input    />
        </Form.Item>
        
        <ProFormDigit
            label="次数"
            name="count"
          
          
          />

        <ProFormDigit
            label="充值金额"
            name="amount"
          
            
          />

           <ProFormDigit
            label="时长"
            name="count_time"
          addonAfter="月"
            
          />
          
      </ModalForm>



    </PageContainer>
  );
};

export default UserList;
