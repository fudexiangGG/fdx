import {
  ProCard,
  ProFormList,
  ProForm,
  ProFormText,
  ProFormTextArea,
  StepsForm,
} from '@ant-design/pro-components';
import { FormattedMessage, useIntl } from '@umijs/max';

import React,{useState} from 'react';
import { Modal,Checkbox,Space,AutoComplete, Form } from 'antd';
import { GetTicket } from '@/services/ant-design-pro/api';

export type FormValueType = {
  target?: string;
  template?: string;
  type?: string;
  time?: string;
  frequency?: string;
} & Partial<API.GetTicketListItem>;

export type UpdateFormProps = {
  onCancel: (flag?: boolean, formVals?: FormValueType) => void;
  onSubmit: (values: FormValueType) => Promise<void>;
  updateModalOpen: boolean;
  values: API.GetTicketListItem;
  close: boolean;
};



const UpdateForm: React.FC<UpdateFormProps> = (props) => {
  const intl = useIntl();
  const [value, setValue] = useState(false);

  const [value2, setValue2] = useState(false);
      

  return (


    <StepsForm
      
      stepsProps={{
        size: 'small',
      }}
      stepsFormRender={(dom, submitter) => {
        
        return (
          <Modal
            width={640}
            bodyStyle={{ padding: '32px 40px 48px' }}
            destroyOnClose
            title="工单详情"
            open={props.updateModalOpen}
            footer={submitter}
            onCancel={() => {
              props.onCancel();
            }}
          >
            {dom}
          </Modal>
        );
      }}
      // 
      
      onFinish={(values) => {
        props.onSubmit(values)
        return Promise.resolve(true);
      }}
    >
      <StepsForm.StepForm
       disabled={props.close}
        request={GetTicket}
        params={{id:props.values.id}}
        title='基础参数'
      >
     <ProForm.Item label="允许的最大曝光范围(mm)" name="MaximumExposureRange"   rules={[
            {
              required: true,
            }
          ]} >

        <AutoComplete
          options={[
            { value: '26 X 32', label: '26 X 32' },
            { value: '22 X 22', label: '22 X 22' },
            { value: '10 X 10', label: '10 X 10' },
          ]}
          placeholder="请输入"
        
          />
        </ProForm.Item>



        <ProForm.Item label="使用晶圆尺寸(inch)" name="WaferInch"   rules={[
            {
              required: true,
            }
          ]} >

        <AutoComplete
          options={[
            { value: '6', label: '6' },
            { value: '8', label: '8' },
            { value: '12', label: '12' },
          ]}
          placeholder="请输入"
        
          />
        </ProForm.Item>

        

        <ProForm.Item label="晶圆无效区宽度" name="WaferInvalidWidth"   rules={[
            {
              required: true,
            }
          ]} >

        <AutoComplete
          options={[
            { value: '3mm', label: '3mm' },
            { value: '5mm', label: '5mm' },
           
          ]}
          placeholder="请输入"
        
          />
        </ProForm.Item>


        

        <ProForm.Item label="曝光单元Y间距(mm)" name="ExposureYSpacing"   rules={[
            {
              required: true,
            }
          ]} >

        <AutoComplete
          options={[
            { value: '0.06', label: '0.06' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
          placeholder="请输入"
        
          />
        </ProForm.Item>
            
        



        <ProForm.Item label="曝光单元X间距(mm)" name="ExposureXSpacing"   rules={[
            {
              required: true,
            }
          ]} >

        <AutoComplete
          options={[
            { value: '0.06', label: '0.06' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
          placeholder="请输入"
        
          />
        </ProForm.Item>

       




        <ProForm.Item label="划片槽宽度(mm，划片槽层次中最外层宽度)" name="GrooveWidth"   rules={[
            {
              required: true,
            }
          ]} >

        <AutoComplete
          options={[
            { value: '0.06', label: '0.06' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
          placeholder="请输入"
        
          />
        </ProForm.Item>

        



        <ProForm.Item label="激光切割缓冲区宽度(mm)" name="LaserCuttingWidth"   rules={[
            {
              required: true,
            }
          ]} >

        <AutoComplete
          options={[
            { value: '0.1', label: '0.1' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
          placeholder="请输入"
        
          />
        </ProForm.Item>


        


        <ProFormTextArea width="lg" name="OtherRequirements" label="其他技术需求" />


      </StepsForm.StepForm>
      <StepsForm.StepForm
             disabled={props.close}
       request={GetTicket}
       params={{id:props.values.id}}
        title='芯片尺寸'
      >
   <ProFormList
        name="attributes"
        creatorButtonProps={{
          creatorButtonText: '添加芯片尺寸',
        }}
        min={1}
        copyIconProps={false}
        itemRender={({ listDom, action }, { index }) => (
          <ProCard
            bordered
            style={{ marginBlockEnd: 8 }}
            title={`Die Size-${index + 1}`}
            extra={action}
            bodyStyle={{ paddingBlockEnd: 0 }}
          >
            {listDom}
          </ProCard>
          
        )}
        creatorRecord={{ name: '', items: [{ name: '' }] }}
      >
        <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="ChipName"
          label="芯片名"
        />
         <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="Xsize"
          label="X尺寸"
        />
         <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="Ysize"
          label="Y尺寸"
        />
      
      <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="name"
          label="ChipsCount"
        />
      </ProFormList>
      </StepsForm.StepForm>
      <StepsForm.StepForm
             disabled={props.close}
         request={GetTicket}
         params={{id:props.values.id}}
        title='功能选择'
      >
        <Space direction="vertical" size="middle" >
        <Form.Item name="MpwDesign" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >最优shotsize下的最优的MPW拼版方案设计</Checkbox>
        </Form.Item>

        <Form.Item name="ExposureUnitsNumber" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >已知shot大小计算最多完整的曝光单元数量</Checkbox>
        </Form.Item>

        <Form.Item name="ChipsNumber" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >量产：已知芯片大小，计算完整的芯片颗数</Checkbox>
        </Form.Item>

        <Form.Item name="ExposureMap" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >提供对应的shot/单颗芯片曝光地图</Checkbox>
        </Form.Item>


        <Form.Item name="ListChipCount" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >成品晶圆每款可获得芯片颗数列表</Checkbox>
        </Form.Item>

        <Form.Item name="ChipSizeDesign" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >固定芯片面积下的最优size设计</Checkbox>
        </Form.Item>


        <Form.Item name="MassProductionPieceAssembly" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >专业软件优化的量产片拼版方案</Checkbox>
        </Form.Item>


        <Form.Item name="OtherIndustries" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >相关其他产业链资源支撑服务</Checkbox>
        </Form.Item>

        <Form.Item name="ExposureParameters" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >最佳曝光参数设置</Checkbox>
        </Form.Item>
      

        <Form.Item name="LaserCutting"  valuePropName="checked">
        <Checkbox  onClick={() => {
          setValue(!value);
        }} disabled={value2 } style={{fontSize:20}} >激光切割</Checkbox>
        </Form.Item>


        <Form.Item name="DiamondCutting"  valuePropName="checked">
        <Checkbox onClick={() => {
          setValue2(!value2);
        }} disabled={value}  style={{fontSize:20}} >金刚石切割</Checkbox>
        </Form.Item>

        </Space>
        
      </StepsForm.StepForm>
    </StepsForm>


    
  );
};

export default UpdateForm;
