import { getDialog,addTicket, FileDlete, adminticketend,addDialog,FileList,endTicket } from '@/services/ant-design-pro/api';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns,  } from '@ant-design/pro-components';
import {
  FooterToolbar,
  ModalForm,
  ProFormList,
  PageContainer,
  ProCard,
  ProFormUploadDragger,
  ProFormTextArea,
  ProTable,
} from '@ant-design/pro-components';
import { UploadOutlined } from '@ant-design/icons';
import { FormattedMessage, useIntl ,useModel} from '@umijs/max';
import { Button, Space,Tag, Input, message,Avatar,Rate,Form } from 'antd';
import React, { useRef, useState } from 'react';
import type { FormValueType } from '../components/UpdateForm';
import UpdateForm from '../components/UpdateForm';
import PostForm from '../components/PostForm';












/**
 * @en-US Add node
 * @zh-CN 添加节点
 * @param fields
 */
const handleAdd = async (fields: API.DialogItem) => {
  if (! fields.dialog) {
    return true;
  }

  const hide = message.loading('正在添加');
  try {
    
    await addDialog({ ...fields });
    hide();
    message.success('Added successfully');
    return true;
  } catch (error) {
    hide();
    message.error('Adding failed, please try again!');
    return false;
  }
};


/**
 * @en-US Add node
 * @zh-CN 添加节点
 * @param fields
 */
const handleTicketAdd = async (fields: API.TicketListItem) => {
  const hide = message.loading('正在添加');
  try {
    await addTicket({ ...fields });
    hide();
    message.success('Added successfully');
    return true;
  } catch (error) {
    hide();
    message.error('Adding failed, please try again!');
    return false;
  }
};


/**
 * @en-US Update node
 * @zh-CN 更新节点
 *
 * @param fields
 */
const handleUpdate = async (fields: FormValueType) => {
  const hide = message.loading('Configuring');
  try {
    // await updateRule({
    //   name: fields.username,
    //   desc: fields.desc,
    //   key: fields.key,
    // });
    hide();

    message.success('Configuration is successful');
    return true;
  } catch (error) {
    hide();
    message.error('Configuration failed, please try again!');
    return false;
  }
};

/**
 *  Delete node
 * @zh-CN 删除节点
 *
 * @param selectedRows
 */
const handleRemove = async () => {
  
};

const TableList: React.FC = () => {
  /**
   * @en-US Pop-up window of new window
   * @zh-CN 新建窗口的弹窗
   *  */
  const [createModalOpen, handleModalOpen] = useState<boolean>(false);
  const [createCommitModalOpen, handlecreateCommitModalOpen] = useState<boolean>(false);
  const [uploadModalOpen, handleuploadModalOpen] = useState<boolean>(false);
  const [endModalOpen, handleendModalOpen] = useState<boolean>(false);
  /**
   * @en-US The pop-up window of the distribution update window
   * @zh-CN 分布更新窗口的弹窗
   * */

  const [updateModalOpen, handleUpdateModalOpen] = useState<boolean>(false);
  const [showDetail, setShowDetail] = useState<boolean>(false);
  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<API.GetTicketListItem>();
  
  const [selectedRowsState, setSelectedRows] = useState<API.GetTicketListItem[]>([]);
  const [fileList, setFileList] = useState<FileList[]>([]);


  const funcfilelist = async  ( id: string | undefined ) => {
    const l = await FileList({id:id})
    setFileList(l)
    return true
  }
  /**
   * @en-US International configuration
   * @zh-CN 国际化配置
   * */
  const intl = useIntl();
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};
  const columns: ProColumns<API.GetTicketListItem>[] = [
    {
      title: "工单号",
      dataIndex: 'id',
      search: false,
    },
    {
      title: "客户",
      dataIndex: 'username',
      search: true,
    },
    {
      title: "状态",
      dataIndex: 'status',
      hideInForm: true,
      search: false,
      valueEnum: {
       
        2: {
            text: "已完成",
            status: 'Success',
          }
      },
    },
   
    {
      title: "评分",
      dataIndex: 'score',
      search: false,
      valueType:"rate"
    },
    {
        title: "评价",
        dataIndex: 'comment',
        search: false,
        valueType:"textarea"
      },
    {
      title: "创建时间",
      
      sorter: false,
      search: false,
      dataIndex: 'create_time',
      valueType: 'dateTime',

    },
    {
        title: "结单时间",
        
        sorter: false,
        search: false,
        dataIndex: 'create_time',
        valueType: 'dateTime',
  
      },
  

    
    {
      title: <FormattedMessage id="pages.searchTable.titleOption" defaultMessage="Operating" />,
      dataIndex: 'option',
      valueType: 'option',
   
      render: (_, record) => [
        <Button
          key="config"
          onClick={() => {
          
             setCurrentRow(record)
             handleUpdateModalOpen(true);
            
          }}
        >
          详情
        </Button>,
        <Button key="subscribeAlert"  onClick={() => {
          
          setCurrentRow(record)
          handlecreateCommitModalOpen(true);
         
       }}>
         与客户沟通
        </Button>,
         <Button key="upload" onClick={  () => {
          setCurrentRow(record)
          handleuploadModalOpen(true)
         }}>
         文件上传
       </Button>,

      ],
    },
  ];

  return (
    <PageContainer>

      <ProTable<API.GetTicketListItem, API.PageParams>
        headerTitle=''
        
        actionRef={actionRef}
        rowKey="id"
        // search={true}
        toolBarRender={() => [
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              handleModalOpen(true);
            }}
          >
            <PlusOutlined /> <FormattedMessage id="pages.searchTable.new" defaultMessage="New" />
          </Button>,
        ]}
        request={adminticketend}
     
        columns={columns}
        rowSelection={{
          onChange: (_, selectedRows) => {
            setSelectedRows(selectedRows);
          },
        }}
      />

      {selectedRowsState?.length > 0 && (
        <FooterToolbar
          extra={
            <div>
              <FormattedMessage id="pages.searchTable.chosen" defaultMessage="Chosen" />{' '}
              <a style={{ fontWeight: 600 }}>{selectedRowsState.length}</a>{' '}
              <FormattedMessage id="pages.searchTable.item" defaultMessage="项" />
              &nbsp;&nbsp;
              <span>
                <FormattedMessage
                  id="pages.searchTable.totalServiceCalls"
                  defaultMessage="Total number of service calls"
                />{' '}
                {/* {selectedRowsState.reduce((pre, item) => pre + item.callNo!, 0)}{' '} */}
                <FormattedMessage id="pages.searchTable.tenThousand" defaultMessage="万" />
              </span>
            </div>
          }
        >
          <Button
            onClick={async () => {
              await handleRemove();
              setSelectedRows([]);
              actionRef.current?.reloadAndRest?.();
            }}
          >
            <FormattedMessage
              id="pages.searchTable.batchDeletion"
              defaultMessage="Batch deletion"
            />
          </Button>
          <Button type="primary">
            <FormattedMessage
              id="pages.searchTable.batchApproval"
              defaultMessage="Batch approval"
            />
          </Button>
        </FooterToolbar>
      )}
      
      
    
     
      <PostForm
       onSubmit={async (value) => {
        const success = await handleTicketAdd(value);
        if (success) {
          handleModalOpen(false);
          if (actionRef.current) {
            actionRef.current.reload();
          }
        }
      }}
      onCancel={() => {
        handleModalOpen(false);
  
      }}
      createModalOpen={createModalOpen}
      />
        


       
       

      <UpdateForm
         
        onSubmit={async (value) => {
          const success = await handleUpdate(value);
          if (success) {
            handleUpdateModalOpen(false);
            setCurrentRow(undefined);
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
        
        onCancel={() => {
          handleUpdateModalOpen(false);
          if (!showDetail) {
            setCurrentRow(undefined);
          }
        }}
        updateModalOpen={updateModalOpen}
        values={currentRow || {} }
      />




      <ModalForm
        disabled
        title=""
        modalProps={{
        destroyOnClose: true,}}
        request={getDialog}
        params={{id:currentRow?.id}}
        width="800px"
        open={createCommitModalOpen}
        onOpenChange={handlecreateCommitModalOpen}


        onFinish={async (value) => {

          const success = await handleAdd(value as  API.DialogItem);
        
          if (success) {
            handlecreateCommitModalOpen(false);
          
          }
        }}
      >
 


      <ProFormList
      
        name="dialog"
        creatorButtonProps={{
          creatorButtonText: '反馈',
        }}
        min={1}
        
        copyIconProps={false}
        itemRender={({ listDom, action, }, listMeta) => (
         
          <ProCard
            
            bordered
            subTitle={
              <Space size={0}>
                  { currentUser?.username == listMeta.record.user ?  <Avatar src="/5.jpg" />   :  <Avatar src="/43.jpg" /> } 
                  
                  { currentUser?.username == listMeta.record.user ?  <Tag color="blue">你</Tag>   : <Tag color="#5BD8A6">{listMeta.record.user}</Tag> } 
                  </Space>
            }
            style={{ marginBlockEnd: 8 }}
            title=" "
            bodyStyle={{ paddingBlockEnd: 0 }}
          >
          <ProFormTextArea
          required
          disabled={ listMeta.record.data }
          style={{ padding: 0 , width: 304}}
          name="data"
          />
          </ProCard>
          
        )}
        creatorRecord={{ data: '',user: currentUser?.username,id:currentRow?.id }}
      >
      
     

      </ProFormList>

      </ModalForm>
      





          <ModalForm
            width={640}
            request={funcfilelist}
            params={currentRow?.id}
            modalProps={{
              destroyOnClose: true,
              style:{ padding: '32px 40px 48px' }
            }}
            title="文件上传"
            disabled
            open={uploadModalOpen}
            onOpenChange={handleuploadModalOpen}

            onFinish={ async ()=> {
              handleuploadModalOpen(false)
            }}
          >
           <ProFormUploadDragger 
              action={'/v1/upload/file?id='+currentRow?.id}
              value={fileList}
              onChange={ async (info) => {


                if (info.file.response ) {
                  info.file.name = info.file.response.name
                  info.file.url = info.file.response.url
                }

                if (info.file.status === 'removed') {
                 const res =  await FileDlete({id:currentRow?.id,filename:info.file.name})
                 

                }
                if (info.fileList) {
                  setFileList(info.fileList);

                }

              }}
             >
             <Button icon={<UploadOutlined />}>Upload</Button>
          </ProFormUploadDragger>
          
      </ModalForm>

        


     
    </PageContainer>
  );
};

export default TableList;
