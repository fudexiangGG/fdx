import {billadd,  billist,  BillFileDlete,BillFileList } from '@/services/ant-design-pro/api';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns,  } from '@ant-design/pro-components';
import { UploadOutlined } from '@ant-design/icons';
import {
  
  ProFormUploadDragger,
  ModalForm,
  ProFormText,
  PageContainer,
  ProTable,
  ProFormDigit,
} from '@ant-design/pro-components';
import { FormattedMessage, useIntl ,useModel} from '@umijs/max';
import { Button,Form, message,Radio, Popconfirm, } from 'antd';
import { RadioChangeEvent } from 'antd/lib';
import React, { useRef, useState } from 'react';


/**
 * @en-US Add node
 * @zh-CN 添加节点
 * @param fields
 */
const handleAddBill = async (fields: API.Bill) => {

  const hide = message.loading('正在添加');
  try {
    
    await billadd({...fields});
    hide();
    message.success('Successfully!');
    return true;
  } catch (error) {
    hide();
    message.error('Failed!');
    return false;
  }
};











const UserList: React.FC = () => {
  /**
   * @en-US The pop-up window of the distribution update window
   * @zh-CN 分布更新窗口的弹窗
   * */
  const [CreateBillModalOpen,handleCreateBillModalOpen] = useState<boolean>(false);
  const [disabledBillInfo,handledisabledBillInfo] = useState<boolean>(false);
  const [uploadModalOpen,handleuploadModalOpen] = useState<boolean>(false);
  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<API.Bill>();
  const [selectedRowsState, setSelectedRows] = useState<API.Bill[]>([]);
  const [value1, setValue1] = useState('');
  const [value2, setValue2] = useState(undefined);

  const [fileList, setFileList] = useState<FileList[]>([]);

  const onChange1 = ({ target: { value } }: RadioChangeEvent) => {
    setValue1(value);
  };

  const onChange2 = ({ target: { value } }: RadioChangeEvent) => {
    setValue2(value);
  };

  const funcfilelist = async  ( id: string | undefined ) => {
    const l = await BillFileList({id:id})
    setFileList(l)
    return true
  }

  const options = [
    { label: '个人', value: 'personal' },
    { label: '公司', value: 'company' },
  ];

  const options2 = [
    { label: '增值税普通发票', value: 'normal' },
    { label: '增值税专用发票', value: 'company' },
  ];
  const options3 = [
    { label: '增值税普通发票', value: 'normal' },
    { label: '增值税专用发票', value: 'company',"disabled":true },
  ];
  /**
   * @en-US International configuration
   * @zh-CN 国际化配置
   * */
  const intl = useIntl();
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const columns: ProColumns<API.Bill>[] = [
    {
      title: "ID",
      dataIndex: 'id',
      search: false,
    },
  
    
    {
      title: "发票类型",
      dataIndex: 'billType',
      search: false,
      valueType: 'select',
      fieldProps: {
        options: [
          {
            label: '增值税普通发票',
            value: 'normal',
          },
          {
            label: '增值税专用发票',
            value: 'company',
          },
          
        ],
      },
    },
   
    {
      title: "发票抬头",
      dataIndex: 'billHead',
      valueType: 'select',
      fieldProps: {
        options: [
          {
            label: '个人',
            value: 'personal',
          },
          {
            label: '公司',
            value: 'company',
          },
          
        ],
      },
      search: false,
    },
    {
      title: "发票金额",
      dataIndex: 'billAmount',
      search: false,
      valueType:"text"
    },

    {
      title: "开票状态",
      dataIndex: 'billDownload',
      search: false,
      valueType:"text"
    },
    {
      title: <FormattedMessage id="pages.searchTable.titleOption" defaultMessage="Operating" />,
      dataIndex: 'option',
      valueType: 'option',
   
      render: (_, record) => [

        <Button
        key="config"
        onClick={() => {

          if (record.billHeadType) {
            setValue1(record.billHeadType)

          }

     
           setCurrentRow(record)
           handleCreateBillModalOpen(true);
           handledisabledBillInfo(true)
          
        }}
      >
        详情
      </Button>,
                <Button hidden={currentUser?.role == 'admin'? false  :true} key="upload" onClick={  () => {
          setCurrentRow(record)
          handleuploadModalOpen(true)
          actionRef.current?.reload()

         }}>
         发票上传
       </Button>,

      <Button  hidden={currentUser?.role == 'admin'? false  :true} style={{color:"white",backgroundColor:"#73d13d",borderColor:"#73d13d"}} key="billendticket"
       onClick={  () => {
        setCurrentRow(record)
      }}>
        开票完成
      </Button>
      ],
    },
  ];

  return (
 
    <PageContainer>
  <ProTable<API.Bill, API.PageParams>
        headerTitle={currentUser?.role == 'admin' ? '' : "可开票金额: "+currentUser?.billAmount +"元" }
        actionRef={actionRef}
        rowKey="id"
        search={false}
        toolBarRender={() => [
          <Button
           hidden={currentUser?.role == 'admin'? true  :false}
            type="primary"
            key="primary"
            onClick={() => {
              handleCreateBillModalOpen(true);
            }}
          >
            <PlusOutlined /> 申请开票
          </Button>,
        ]}
        request={billist}
        columns={columns}
        rowSelection={{
          onChange: (_, selectedRows) => {
            setSelectedRows(selectedRows);
          },
        }}
      />
  
        <ModalForm
            initialValues={{
              billHeadType: currentRow?.billHeadType,
              billType: currentRow?.billType,
              billHead: currentRow?.billHead,
              billIdentifier: currentRow?.billIdentifier,
              billAccountBank: currentRow?.billAccountBank,
              billAccount: currentRow?.billAccount,
              billCompanyAddress: currentRow?.billCompanyAddress,
              billCompanyPhone: currentRow?.billCompanyPhone,
              billAmount: currentRow?.billAmount,
              
            }}
            disabled={disabledBillInfo}
            width={640}
            modalProps={{
              destroyOnClose: true,
              style:{ padding: '32px 40px 48px' }
            }}
            title="添加邮箱"
            open={CreateBillModalOpen}
            onOpenChange={handleCreateBillModalOpen}

            onFinish={ async (value)=> {
              if (currentUser?.amount){
                if (value.billAmount > currentUser?.amount) {

                  message.error('开票金额大于消费总金额!');
                  return
              } 
              }else {

                message.error('没有消费金额!');
                return
              }
             
              const success = await handleAddBill(value as API.Bill );
              if (success) {
                handleCreateBillModalOpen(false);
                if (actionRef.current) {
                  actionRef.current.reload();
                }
              }
            }}
          >

        <Form.Item label="抬头类型" name="billHeadType">
        <Radio.Group

                        options={options}
                        onChange={onChange1}
                        value={value1}
                        optionType="button"
                        buttonStyle="solid"
                      />
        </Form.Item>
               

        <Form.Item label="发票类型" name="billType">
        <Radio.Group

                        options={ value1 == "personal" ?  options3 : options2}
                        onChange={onChange2}
                        value={value2}
                        optionType="button"
                        buttonStyle="solid"
                      />
        </Form.Item>

            <ProFormText
                name="billHead"
                label="发票抬头"
                hidden={ value1 == "personal" ?  true : false}
                disabled={ value1 == "personal" ?  true : false}
               
              />


            <ProFormText
             
                name="billIdentifier"
                label="纳税人识别号"
                hidden={ value1 == "personal" ?  true : false}
                disabled={ value1 == "personal" ?  true : false}
    
              />


            <ProFormText
             
                name="billAccountBank"
                label="基本开户银行"
                hidden={ value1 == "personal" ?  true : false}
                disabled={ value1 == "personal" ?  true : false}
              
              />



            <ProFormText
              
                name="billAccount"
                label="基本开户账号"
                hidden={ value1 == "personal" ?  true : false}
                disabled={ value1 == "personal" ?  true : false}
              
              />


            <ProFormText
             
                name="billCompanyAddress"
                label="企业注册地址"
                hidden={ value1 == "personal" ?  true : false}
                disabled={ value1 == "personal" ?  true : false}
               
              />



            <ProFormText
                name="billCompanyPhone"
                label="企业注册电话"
                hidden={ value1 == "personal" ?  true : false}
                disabled={ value1 == "personal" ?  true : false}
                
              />
       
       <ProFormDigit
                name="billAmount"
                label="开票金额"
              
                
              />
          
      </ModalForm>



      <ModalForm
            width={640}
            request={funcfilelist}
            params={currentRow?.id}
            modalProps={{
              destroyOnClose: true,
              style:{ padding: '32px 40px 48px' }
            }}
            title="文件上传"
            open={uploadModalOpen}
            onOpenChange={handleuploadModalOpen}

            onFinish={ async ()=> {
              handleuploadModalOpen(false)
            }}
          >
           <ProFormUploadDragger 
              action={'/v1/bill/file/upload?id='+currentRow?.id}
              value={fileList}
              onChange={ async (info) => {


                if (info.file.response ) {
                  info.file.url = info.file.response.url
                }

                if (info.file.status === 'removed') {
                 const res =  await BillFileDlete({id:currentRow?.id,filename:info.file.name})
                 

                }
                if (info.fileList) {
                  setFileList(info.fileList);

                }

              }}
             >
             <Button icon={<UploadOutlined />}>Upload</Button>
          </ProFormUploadDragger>
          
      </ModalForm>


    </PageContainer>
  );
};

export default UserList;
