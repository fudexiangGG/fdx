import {AddUser, userdelete,userlist,UpdateUser, emailadd, emaildelete, emaillist } from '@/services/ant-design-pro/api';
import { PlusOutlined } from '@ant-design/icons';
import type { ActionType, ProColumns,  } from '@ant-design/pro-components';
import {
 
  ProFormDigit,
  ModalForm,
  ProFormText,
  PageContainer,
  ProTable,
} from '@ant-design/pro-components';
import { FormattedMessage, useIntl ,useModel} from '@umijs/max';
import { Button,Input, message,Form, Popconfirm, } from 'antd';
import React, { useRef, useState } from 'react';


/**
 * @en-US Add node
 * @zh-CN 添加节点
 * @param fields
 */
const handleAddEmial = async (fields: string) => {

  const hide = message.loading('正在添加');
  try {
    
    await emailadd({email:fields});
    hide();
    message.success('Successfully!');
    return true;
  } catch (error) {
    hide();
    message.error('Failed!');
    return false;
  }
};





const handleDleteEmail = async (fields: string |undefined) => {

  const hide = message.loading('正在删除');
  try {
    
    await emaildelete({email:fields});
    hide();
    message.success('Successfully!');
    return true;
  } catch (error) {
    hide();
    message.error('Failed!');
    return false;
  }
};






const UserList: React.FC = () => {
  /**
   * @en-US The pop-up window of the distribution update window
   * @zh-CN 分布更新窗口的弹窗
   * */
  const [CreateEmailModalOpen,handleCreateEmailModalOpen] = useState<boolean>(false);
  const [updateModalOpen, handleUpdateModalOpen] = useState<boolean>(false);
  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<API.Email>();
  const [selectedRowsState, setSelectedRows] = useState<API.Email[]>([]);

  /**
   * @en-US International configuration
   * @zh-CN 国际化配置
   * */
  const intl = useIntl();
  const { initialState } = useModel('@@initialState');
  const { currentUser } = initialState || {};

  const columns: ProColumns<API.Email>[] = [
    {
      title: "ID",
      dataIndex: 'id',
      search: false,
    },
  
    
    {
      title: "邮箱",
      dataIndex: 'email',
      search: false,
      valueType:"text"
    },
   
    {
      title: <FormattedMessage id="pages.searchTable.titleOption" defaultMessage="Operating" />,
      dataIndex: 'option',
      valueType: 'option',
   
      render: (_, record) => [

      

        
        <Popconfirm
          title="Delete the email"
          description="Are you sure to delete this email?"
          onConfirm={() => {
            handleDleteEmail(record.email)
            actionRef.current?.reload()
  
           }}
          okText="Yes"
          cancelText="No"
        >
         <Button danger key="deleteemial" >
         删除
       </Button>
       </Popconfirm>
       
      ],
    },
  ];

  return (
    <PageContainer>

      <ProTable<API.Email, API.PageParams>
        headerTitle=''
        actionRef={actionRef}
        rowKey="id"
        search={false}
        toolBarRender={() => [
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              handleCreateEmailModalOpen(true);
            }}
          >
            <PlusOutlined /> 邮箱
          </Button>,
        ]}
        request={emaillist}
        columns={columns}
        rowSelection={{
          onChange: (_, selectedRows) => {
            setSelectedRows(selectedRows);
          },
        }}
      />

  
        <ModalForm
          
            width={640}
            modalProps={{
              destroyOnClose: true,
              style:{ padding: '32px 40px 48px' }
            }}
            title="添加邮箱"
            open={CreateEmailModalOpen}
            onOpenChange={handleCreateEmailModalOpen}

            onFinish={ async (value)=> {
              const success = await handleAddEmial(value.email);
              if (success) {
                handleCreateEmailModalOpen(false);
                if (actionRef.current) {
                  actionRef.current.reload();
                }
              }
            }}
          >
       
            <ProFormText
            
                name="email"
                label="用户名"
                placeholder="请输入邮箱"
                rules={[
                  
                    {
                      required: true,
                      message: "请输入邮箱",
                    },
                    {
                      pattern: /^[a-zA-Z0-9]+([-_.][A-Za-zd]+)*@([a-zA-Z0-9]+[-.])+[A-Za-zd]{2,5}$/,
                      message: "邮箱格式错误",
                    },
                  
                ]}
              />

       
          
      </ModalForm>




    </PageContainer>
  );
};

export default UserList;
