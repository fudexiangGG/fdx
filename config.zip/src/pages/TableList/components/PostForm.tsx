import { event } from '@/.umi/plugin-locale/localeExports';
import {
   StepsForm,
    ProFormSelect,
    ProFormText,
    ProFormTextArea,
    ProFormList,
    ProForm,
    ProCard
  } from '@ant-design/pro-components';
import { FormattedMessage, useIntl } from '@umijs/max';
import { Modal,Checkbox,Space, Form } from 'antd';
import React, { useState } from 'react';
  
  export type FormValueType = {
    MaximumExposureRange?: string;
    WaferInch?: string;
    WaferInvalidWidth?: string;
    ExposureYSpacing?: string;
    ExposureXSpacing?: string;
  } & Partial<API.TicketListItem>;
  
  export type PostFormProps = {
    onCancel: (flag?: boolean, formVals?: FormValueType) => void;
    onSubmit: (values: FormValueType) => Promise<void>;
    createModalOpen: boolean;
  };
 
  const PostForm: React.FC<PostFormProps> = (props) => {

   return (
<StepsForm
      stepsProps={{
        size: 'small',
      }}
      stepsFormRender={(dom, submitter) => {
        return (
          <Modal
            width={640}
            bodyStyle={{ padding: '32px 40px 48px' }}
            destroyOnClose
            title= '新建工单'
            open={props.createModalOpen}
            footer={submitter}
            onCancel={() => {
              props.onCancel();
            }}
          >
            {dom}
          </Modal>
        );
      }}
      onFinish={props.onSubmit}
    >
      <StepsForm.StepForm
       
        title='基础参数'
      >
<ProFormSelect
  
          label="允许的最大曝光范围(mm)"
          width="lg"
          mode="tags"
          name="MaximumExposureRange"
          rules={[
            {
              required: true,
            }
          ]}

          options={[
            { value: '26 X 32', label: '26 X 32' },
            { value: '22 X 22', label: '22 X 22' },
            { value: '10 X 10', label: '10 X 10' },
          ]}
         
        
        />

        <ProFormSelect
          
          label="使用晶圆尺寸(inch)"
          width="lg"
          mode="tags"
          name="WaferInch"
          rules={[
            {
              required: true,
            }
          ]}

          options={[
            { value: '6', label: '6' },
            { value: '8', label: '8' },
            { value: '12', label: '12' },
          ]}
          

        />


        <ProFormSelect
          
          label="晶圆无效区宽度"
          width="lg"
          mode="tags"
          name="WaferInvalidWidth"
          rules={[
            {
              required: true,
            }
          ]}

          options={[
            { value: '3mm', label: '3mm' },
            { value: '5mm', label: '5mm' },
           
          ]}

  

        />
            
        

        <ProFormSelect
          label="曝光单元Y间距(mm)"
          width="lg"
          mode="tags"
          name="ExposureYSpacing"
          rules={[
            {
              required: true,
            }
          ]}
          options={[
            { value: '0.06', label: '0.06' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
         
        />


        <ProFormSelect
          label="曝光单元X间距(mm)"
          width="lg"
          mode="tags"
          name="ExposureXSpacing"
          rules={[
            {
              required: true,
            }
          ]}

          options={[
            { value: '0.06', label: '0.06' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
 
        />

        <ProFormSelect
          label="划片槽宽度(mm，划片槽层次中最外层宽度)"
          width="lg"
          mode="tags"
          name="GrooveWidth"
          rules={[
            {
              required: true,
            }
          ]}

          options={[
            { value: '0.06', label: '0.06' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
        />

        <ProFormSelect
          label="激光切割缓冲区宽度(mm)"
          width="lg"
          mode="tags"
          name="LaserCuttingWidth"
          rules={[
            {
              required: true,
            }
          ]}

          options={[
            { value: '0.1', label: '0.1' },
            { value: '0.78', label: '0.78' },
            { value: '0.08', label: '0.08' },
           
          ]}
        />


        <ProFormTextArea width="lg" name="OtherRequirements" label="其他技术需求" />

      </StepsForm.StepForm>
      <StepsForm.StepForm
       
        title='芯片尺寸'
      >
   <ProFormList
        name="attributes"
        creatorButtonProps={{
          creatorButtonText: '添加芯片尺寸',
        }}
        min={1}
        copyIconProps={false}
        itemRender={({ listDom, action }, { index }) => (
          <ProCard
            bordered
            style={{ marginBlockEnd: 8 }}
            title={`Die Size-${index + 1}`}
            extra={action}
            bodyStyle={{ paddingBlockEnd: 0 }}
          >
            {listDom}
          </ProCard>
          
        )}
        creatorRecord={{ name: '', items: [{ name: '' }] }}
      >
        <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="ChipName"
          label="芯片名"
        />
         <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="Xsize"
          label="X尺寸"
        />
         <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="Ysize"
          label="Y尺寸"
        />
      
      <ProFormText
          style={{ padding: 0 }}
          width="lg"
          name="name"
          label="ChipsCount"
        />
      </ProFormList>
      </StepsForm.StepForm>
      <StepsForm.StepForm
       
        title='功能选择'
      >
        <Space direction="vertical" size="middle" >
        <Form.Item name="MpwDesign" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >最优shotsize下的最优的MPW拼版方案设计</Checkbox>
        </Form.Item>

        <Form.Item name="ExposureUnitsNumber" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >已知shot大小计算最多完整的曝光单元数量</Checkbox>
        </Form.Item>

        <Form.Item name="ChipsNumber" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >量产：已知芯片大小，计算完整的芯片颗数</Checkbox>
        </Form.Item>

        <Form.Item name="ExposureMap" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >提供对应的shot/单颗芯片曝光地图</Checkbox>
        </Form.Item>


        <Form.Item name="ListChipCount" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >成品晶圆每款可获得芯片颗数列表</Checkbox>
        </Form.Item>

        <Form.Item name="ChipSizeDesign" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >固定芯片面积下的最优size设计</Checkbox>
        </Form.Item>


        <Form.Item name="MassProductionPieceAssembly" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >专业软件优化的量产片拼版方案</Checkbox>
        </Form.Item>


        <Form.Item name="OtherIndustries" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >相关其他产业链资源支撑服务</Checkbox>
        </Form.Item>

        <Form.Item name="ExposureParameters" valuePropName="checked">
        <Checkbox  style={{fontSize:20}} >最佳曝光参数设置</Checkbox>
        </Form.Item>
      

        <Form.Item name="DiamondCutting" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >金刚石切割</Checkbox>
        </Form.Item>


        <Form.Item name="LaserCutting" valuePropName="checked">
        <Checkbox style={{fontSize:20}} >激光切割</Checkbox>
        </Form.Item>

        </Space>
        
      </StepsForm.StepForm>
    </StepsForm>
    );
  };
  
  export default PostForm;
  