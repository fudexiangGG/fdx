// @ts-ignore
/* eslint-disable */
import { request } from '@umijs/max';
import { UploadFile } from 'antd';

/** 获取当前的用户 GET /api/currentUser */
export async function currentUser(options?: { [key: string]: any }) {
  return request<{
    data: API.CurrentUser;
  }>('/v1/user/get', {
    method: 'GET',
    ...(options || {}),
  });
}

/** 退出登录接口 POST /api/login/outLogin */
export async function outLogin(options?: { [key: string]: any }) {
  return request<Record<string, any>>('/v1/login/outLogin', {
    method: 'GET',
    ...(options || {}),
  });
}

/** 登录接口 POST /api/login/account */
export async function login(body: API.LoginParams, options?: { [key: string]: any }) {
  return request<API.LoginResult>('/v1/user/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}


/** 注册接口 POST /v1/user/create */
export async function Register(body: API.UserRegister, options?: { [key: string]: any }) {
  return request<API.LoginResult>('/v1/user/create', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}


export async function Forgetpass(body: API.UserRegister, options?: { [key: string]: any }) {
  return request<API.LoginResult>('/v1/user/forgetpass', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    data: body,
    ...(options || {}),
  });
}

/** 此处后端没有提供注释 GET /api/notices */
export async function getNotices(options?: { [key: string]: any }) {
  return request<API.NoticeIconList>('/api/notices', {
    method: 'GET',
    ...(options || {}),
  });
}

/** 获取规则列表 GET /api/rule */
export async function adminticketwait(
  params: {
    // query
    /** 当前的页码 */
    current?: number;
    /** 页面的容量 */
    pageSize?: number;
    
  },
  options?: { [key: string]: any },
) {
  return request<API.TicketListItem>('/v1/ticket/list', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}


/** 获取规则列表 GET /api/rule */
export async function adminticketend(
  params: {
    // query
    /** 当前的页码 */
    current?: number;
    /** 页面的容量 */
    pageSize?: number;
    
  },
  options?: { [key: string]: any },
) {
  return request<API.TicketListItem>('/v1/ticket/endlist', {
    method: 'GET',
    params: {
      ...params,

    },
    ...(options || {}),
  });
}


export async function emaillist(
  options?: { [key: string]: any },
) {
  return request<API.Bill[]>('/v1/email/list', {
    method: 'GET',
   
    ...(options || {}),
  });
}



export async function billist(
  options?: { [key: string]: any },
) {
  return request<API.BillItem>('/v1/bill/list', {
    method: 'GET',
   
    ...(options || {}),
  });
}


/** 新建规则 POST /api/ticket/post */
export async function billadd(options?: { [key: string]: any }) {

  return request<API.Bill>('/v1/bill/add', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}



export async function emailadd(
  params: {
    email?: string; 
  },
  options?: { [key: string]: any },
) {
  return request<API.ErrorResponse>('/v1/email/add', {
    method: 'GET',
    params: {
      ...params,
    
    },
    ...(options || {}),
  });
}

export async function emaildelete(
  params: {
    email?: string; 
  },
  options?: { [key: string]: any },
) {
  return request<API.ErrorResponse>('/v1/email/delete', {
    method: 'GET',
    params: {
      ...params,
    
    },
    ...(options || {}),
  });
}


export async function userdelete(
  params: {
    username?: string; 
  },
  options?: { [key: string]: any },
) {
  return request<API.ErrorResponse>('/v1/user/delete', {
    method: 'GET',
    params: {
      ...params,
    
    },
    ...(options || {}),
  });
}



/** 获取规则列表 GET /api/rule */
export async function userlist(
  params: {
    // query
    /** 当前的页码 */
    current?: number;
    /** 页面的容量 */
    pageSize?: number;
    
  },
  options?: { [key: string]: any },
) {
  return request<API.UserListItem>('/v1/user/list', {
    method: 'GET',
    params: {
      ...params,
    
    },
    ...(options || {}),
  });
}


export async function updateticket(
  params: {
   id?: string;
  },
  options?: { [key: string]: any },
) {
  return request<API.ErrorResponse>('/v1/ticket/update', {
    method: 'POST',
    params: {
      ...params,
    
    },
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}

/** 获取规则列表 GET /api/rule */
export async function rule(
  params: {
    // query
    /** 当前的页码 */
    current?: number;
    /** 页面的容量 */
    pageSize?: number;
    
  },
  options?: { [key: string]: any },
) {
  return request<API.GetTicketListItem[]>('/v1/ticket/list', {
    method: 'GET',
    params: {
      ...params,
    
    },
    ...(options || {}),
  });
}

/** 更新规则 PUT /api/rule */
export async function updateRule(options?: { [key: string]: any }) {
  return request<API.GetTicketListItem>('/api/rule', {
    method: 'POST',
    data:{
      method: 'update',
      ...(options || {}),
    }
  });
}


/** 新建规则 POST /api/ticket/post */
export async function addTicket(options?: { [key: string]: any }) {

  return request<API.TicketListItem>('/v1/ticket/create', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}


export async function UpdateUser(options?: { [key: string]: any }) {
  return request<API.ErrorResponse>('/v1/user/update', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}


export async function AddUser(options?: { [key: string]: any }) {
  return request<API.ErrorResponse>('/v1/user/admincreate', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}




/** 新建规则 POST /api/rule */
export async function endTicket(options?: { [key: string]: any }) {
  return request<API.ErrorResponse>('/v1/ticket/end', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}

/** 新建规则 POST /api/rule */
export async function addDialog(options?: { [key: string]: any }) {
  return request<API.DialogItem>('/v1/dialog/create', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}


/** 新建规则 POST /api/rule */
export async function addRule(options?: { [key: string]: any }) {
  return request<API.GetTicketListItem>('/api/rule', {
    method: 'POST',
    data:{
      method: 'post',
      ...(options || {}),
    }
  });
}



export async function getDialog( params: {
   
  id?:string
},options?: { [key: string]: any }) {
  
  return request<API.DialogItem>('/v1/dialog/get', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export  async function GetTicket(
  params: {
   
    id?:string
  },
  options?: { [key: string]: any },
) {
  return request<API.GETTicket>('/v1/ticket/get', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export  async function BillComplate(
  params: {
   
    id?:string
 
  },
  options?: { [key: string]: any },
) {
  return request<API.ErrorResponse>('/v1/bill/complate', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}


export  async function BillFileDlete(
  params: {
   
    id?:string
    filename?:string
  },
  options?: { [key: string]: any },
) {
  return request<API.ErrorResponse>('/v1/bill/file/delete', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}


export  async function FileDlete(
  params: {
   
    id?:string
    filename?:string
  },
  options?: { [key: string]: any },
) {
  return request<API.ErrorResponse>('/v1/file/delete', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export  async function BillFileList(
  params: {
   
    id?:string
  },
  options?: { [key: string]: any },
) {
  return request<FileList[]>('/v1/bill/file/list', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

export  async function FileList(
  params: {
   
    id?:string
  },
  options?: { [key: string]: any },
) {
  return request<FileList[]>('/v1/file/list', {
    method: 'GET',
    params: {
      ...params,
    },
    ...(options || {}),
  });
}


/** 删除规则 DELETE /api/rule */
export async function removeRule(options?: { [key: string]: any }) {
  return request<Record<string, any>>('/api/rule', {
    method: 'POST',
    data:{
      method: 'delete',
      ...(options || {}),
    }
  });
}
