// @ts-ignore
/* eslint-disable */

declare namespace API {
  
  type CurrentUser = {
    username?: string;
    mobile?: string;
    level?: string;
    id?: string;
    role?: string;
    amount?: number;
    billAmount?: number;
  };

  type LoginResult = {
    status?: string;
    type?: string;
    currentAuthority?: string;
  };

  type PageParams = {
    current?: number;
    pageSize?: number;
  };




type FileList = {
  name?:string
  status?:string
  url?:string

}

  type GETTicket = {
    data?: TicketListItem
    success?: boolean
  }


  type UserList = {
    username?:string;
    password?:string;
    mobile?:string;
    level?:string;
    count?:number;
    amount?:number;
    count_time?:number;
    create_time?:string;
  }

  type UserListItem = {
    data?: UserList[]
    success?: boolean
  };


  type TicketListItem = {
    ChipSizeDesign?: boolean;
    ChipsNumber?: boolean;
    DiamondCutting?: boolean;
    ExposureMap?: boolean;
    ExposureParameters?: boolean;
    ExposureUnitsNumber?: boolean;
    LaserCutting?: boolean;
    ListChipCount?: boolean;
    MassProductionPieceAssembly?: boolean;
    MpwDesign?: boolean;
    OtherIndustries?: boolean;
    ExposureXSpacing?:Array[string]
    ExposureYSpacing?:Array[string]
    LaserCuttingWidth?:Array[string]
    GrooveWidth?:Array[string]
    MaximumExposureRange?:Array[string]
    WaferInch?:Array[string]
    WaferInvalidWidt?:Array[string]
    Attributes?:AttributesItem[];
  };

  type AttributesItem = {
    Name?: string;
    ChipName?: string;
    Xsize?: string;
    Ysize?: string;
  }

  


  type AddUser = {
    username?: string;
    password?:number;
    mobile?:string;
    count?:number;
    amount?:number;
    count_time?:number
  }


  type EndTicket = {
    id?:string;
    score?:number;
   
    comment?:string;
  }

  type DialogItem = {
    dialog?: Dialog[];
  }

  type Dialog = {
    data?:string;
    user?:string;
    id?:string;
  }

  type GetTicketListItem = {
    id?: string;
    create_time?: number;
    user_comment_status?: string
    user_file_status?: string
    engineer_comment_status?: string
    engineer_file_status?:string
    status?: string;
    username?: string;
  };

  type BillItem = {
    data?: Bill[]
    success?: boolean;

  }
  type Bill = {
    id?:string
      billHeadType?: string
      billType?: string
      billHead?: string
      billIdentifier?: string
      billAccountBank?: string
      billAccount:? string
      billCompanyAddress?: string
      billCompanyPhone?: string
      billAmount?: number
      billDownload?: string
      username?: string
  }

  
  type Email = {
    id?:string
    email?:string

  }
  type GetTicketList = {
    data?: GetTicketListItem[];
    /** 列表的内容总数 */
    total?: number;

    success?: boolean;
  };

  type FakeCaptcha = {
    code?: number;
    status?: string;
  };

  type UserRegister = {
    username?: string;
    password?: string;
    mobile?: string;
    captcha?: string;

  }
  type LoginParams = {
    username?: string;
    password?: string;
    autoLogin?: boolean;
    type?: string;
  };

  type ErrorResponse = {
    /** 业务约定的错误码 */
    errorCode: string;
    /** 业务上的错误信息 */
    errorMessage?: string;
    /** 业务上的请求是否成功 */
    success?: boolean;
  };

  type NoticeIconList = {
    data?: NoticeIconItem[];
    /** 列表的内容总数 */
    total?: number;
    success?: boolean;
  };

  type NoticeIconItemType = 'notification' | 'message' | 'event';

  type NoticeIconItem = {
    id?: string;
    extra?: string;
    key?: string;
    read?: boolean;
    avatar?: string;
    title?: string;
    status?: string;
    datetime?: string;
    description?: string;
    type?: NoticeIconItemType;
  };
}
