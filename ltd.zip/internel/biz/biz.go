package biz

import (
	"database/sql/driver"
	"encoding/json"
	"log"
	"ltd_backend/internel/transport"
)

type Biz struct {
	mydb Biz_interface
	log  *log.Logger
}

type TicketDialog struct {
	Id string `gorm:"primaryKey;column:id;type:varchar;size:255;not null" json:"id,omitempty"`
	Dialog string `gorm:"primaryKey;column:dialog;type:text;dialog;not null" json:"dialog,omitempty"`
}

type Ticket struct {
	Id         string `gorm:"primaryKey;column:id;type:varchar;size:255;autoIncrement;not null" json:"id,omitempty"`
	Username   string `gorm:"column:username;type:varchar;size:255;not null" json:"username,omitempty"`
	CreateTime int64  `gorm:"column:create_time;type:bigint" json:"create_time,omitempty"`
	Status     string `gorm:"column:status;type:varchar;size:255;not null" json:"status,omitempty"`
	TicketJson string `gorm:"primaryKey;column:ticket_json;type:text;ticket_json;not null" json:"ticket_json,omitempty"`
	Score int `gorm:"column:score;type:int" json:"score,omitempty"`
	Comment string `gorm:"column:comment;type:varchar" json:"comments,omitempty"`
}

type NewTikect struct {
	ChipSizeDesign              bool             `json:"ChipSizeDesign,omitempty"`
	ChipsNumber                 bool             `json:"ChipsNumber,omitempty"`
	DiamondCutting              bool             `json:"DiamondCutting,omitempty"`
	ExposureMap                 bool             `json:"ExposureMap,omitempty"`
	ExposureParameters          bool             `json:"ExposureParameters,omitempty"`
	ExposureUnitsNumber         bool             `json:"ExposureUnitsNumber,omitempty"`
	LaserCutting                bool             `json:"LaserCutting,omitempty"`
	ListChipCount               bool             `json:"ListChipCount,omitempty"`
	MassProductionPieceAssembly bool             `json:"MassProductionPieceAssembly,omitempty"`
	MpwDesign                   bool             `json:"MpwDesign,omitempty"`
	OtherIndustries             bool             `json:"OtherIndustries,omitempty"`
	OtherRequirements           string           `json:"OtherRequirements,omitempty"`
	WaferInvalidWidth           []string         `json:"WaferInvalidWidth,omitempty"`
	ExposureXSpacing            []string         `json:"ExposureXSpacing,omitempty"`
	ExposureYSpacing            []string         `json:"ExposureYSpacing,omitempty"`
	LaserCuttingWidth           []string         `json:"LaserCuttingWidth,omitempty"`
	GrooveWidth                 []string         `json:"GrooveWidth,omitempty"`
	MaximumExposureRange        []string         `json:"MaximumExposureRange,omitempty"`
	WaferInch                   []string         `json:"WaferInch,omitempty"`
	WaferInvalidWidt            []string         `json:"WaferInvalidWidt,omitempty"`
	Attributes                  []Attributeslist `json:"attributes,omitempty"`
}

type Attributeslist struct {
	Name     string `json:"name,omitempty"`
	ChipName string `json:"ChipName,omitempty"`
	Xsize    string `json:"Xsize,omitempty"`
	Ysize    string `json:"Ysize,omitempty"`
}

func (c NewTikect) Value() (driver.Value, error) {
	b, err := json.Marshal(c)
	return string(b), err
}

func (c *NewTikect) Scan(input interface{}) error {
	return json.Unmarshal(input.([]byte), c)
}

type User struct {
	Id         string `gorm:"primaryKey;column:id;type:varchar;size:255;autoIncrement;not null" json:"id,omitempty"`
	Username   string `gorm:"column:username;type:varchar;size:255;not null" json:"username,omitempty"`
	Mobile     string `gorm:"column:mobile;type:varchar;size:255;not null" json:"mobile,omitempty"`
	Level      string `gorm:"column:level;type:varchar;size:255" json:"level,omitempty"`
	Password   string `gorm:"column:password;type:varchar;size:255" json:"password,omitempty"`
	Count      int    `gorm:"column:count;type:int;not null" json:"count,omitempty"`
	CountTime  int64  `gorm:"column:count_time;type:bigint" json:"count_time,omitempty"`
	Amount     int64  `gorm:"column:amount;type:bigint" json:"amount,omitempty"`
	Role       string `gorm:"column:role;type:varchar;size:255;not null" json:"role,omitempty"`
	Token      string `gorm:"column:token;type:varchar;size:255;not null" json:"token,omitempty"`
	ToeknTime  int64  `gorm:"column:toekn_time;type:bigint;not null" json:"toekn_time"`
	CreateTime int64  `gorm:"column:create_time;type:bigint" json:"create_time,omitempty"`
}

func NewBiz(i Biz_interface, log *log.Logger) Biz {
	return Biz{mydb: i, log: log}
}

type Biz_interface interface {
	InsterTicket(ticket *Ticket) error
	InsertUser(user *User) error
	TicketGet(id string) (*Ticket, error)
	TicketList(username string, status string) ([]Ticket, error)
	UserOutLogin(username string) error
	UpdateToken(username string, token string, time int64) error
	GetUser(username string) (*User, error)
	TicketDialogGet(id string) (*TicketDialog,error)
	TicketDialogInster(ticketdialog *TicketDialog) error
	EndTicket(ticketend *transport.EndTicket,username string) error
}

func(b *Biz)  UserOutLogin(username string) error {
	return b.mydb.UserOutLogin(username)
}


func(b *Biz)  EndTicket(ticketend *transport.EndTicket,username string) error {

	return b.mydb.EndTicket(ticketend,username)
}

func(b *Biz) TicketDialogGet(id string) (*TicketDialog,error) {
	return b.mydb.TicketDialogGet(id)
}


func(b *Biz) TicketDialogInster(ticketdialog *TicketDialog) error {
	return b.mydb.TicketDialogInster(ticketdialog)
}

func (b *Biz) TicketGet(id string) (*Ticket, error) {
	return b.mydb.TicketGet(id)
}

func (b *Biz) TicketList(username string, status string) ([]Ticket, error) {

	return b.mydb.TicketList(username, status)

}

func (b *Biz) InsterTicket(ticket *Ticket) error {

	return b.mydb.InsterTicket(ticket)
}

func (b *Biz) UpdateToken(username string, token string, time int64) error {

	return b.mydb.UpdateToken(username, token, time)
}

func (b *Biz) GetUser(username string) (*User, error) {

	return b.mydb.GetUser(username)
}

func (b *Biz) InsertUser(user *User) error {

	return b.mydb.InsertUser(user)
}
