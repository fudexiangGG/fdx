package main

import (
	"bytes"
	"log"
	ltdbiz "ltd_backend/internel/biz"
	ltdconf "ltd_backend/internel/conf"
	ltddata "ltd_backend/internel/data"
	ltdservice "ltd_backend/internel/service"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

func main() {
	//ltd_map := make(map[string]string)
	//ltd_map = map[string]string{"ChipSizeDesign": "固定芯片面积下的最优size设计",
	//"ExposureUnitsNumber": "已知shot大小计算最多完整的曝光单元数量",
	//"ChipsNumber": "量产：已知芯片大小，计算完整的芯片颗数",
	//"LowestCosShotsize": "满足项目需求下的成本最低的shotsize设计方案",
	//"ExposureMap": "提供对应的shot/单颗芯片曝光地图",
	//"MpwDesign": "最优shotsize下的最优的MPW拼版方案设计",
	//"ExposureParameters": "最佳曝光参数设置",
	//"LaserCutting": "激光切割",
	//"DiamondCutting": "金刚石切割",
	//"ListChipCount": "成品晶圆每款可获得芯片颗数列表",
	//"MassProductionPieceAssembly": "专业软件优化的量产片拼版方案",
	//"Resident": "驻场修改、沟通服务（以合同约定使用次数为限）",
	//"OtherIndustries": "相关其他产业链资源支撑服务。（若点选，需要人工进行追进后期生产过程）",
	//}
	buf := &bytes.Buffer{}
	logger := log.New(buf, "Ltd_backend", log.Lshortfile|log.LstdFlags)

	config := ltdconf.GetConfig()
	Mydb := ltddata.NewMydb(&config.Database.Mysql)
	data := ltddata.NewGreeterRepo(Mydb, logger)
	biz := ltdbiz.NewBiz(data, logger)
	Service := ltdservice.NewSercice_interface(biz, logger)

	router := gin.Default()

	router.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"},
		AllowMethods:     []string{"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"},
		AllowHeaders:     []string{"Origin", "Content-Length", "Content-Type"},
		ExposeHeaders:    []string{"Content-Length"},
		AllowCredentials: true,

		MaxAge: 12 * time.Hour,
	}))

	v1 := router.Group("/v1")

	{
		v1.GET("/email/add", Service.CheckLogin(), Service.EmialAdd)
		v1.GET("/email/list", Service.CheckLogin(), Service.EmialList)
		v1.GET("/email/delete", Service.CheckLogin(), Service.EmailDelete)
		v1.GET("/verifiyCode",  Service.GetVerifiyCode)
		v1.GET("/user/get", Service.CheckLogin(), Service.CurrentUser)
		v1.GET("/ticket/list", Service.CheckLogin(), Service.TicketList)
		v1.GET("/ticket/endlist", Service.CheckLogin(), Service.EndTicketList)
		v1.GET("/ticket/get", Service.CheckLogin(), Service.TicketGet)
		v1.GET("/dialog/get", Service.CheckLogin(), Service.TicketDialogGet)
		v1.GET("/file/download", Service.CheckLogin(), Service.FilewDownload)
		v1.GET("/user/list", Service.AdminCheckLogin(), Service.UserList)
		v1.GET("/user/delete", Service.AdminCheckLogin(), Service.AdminDeleteUser)
		v1.POST("/user/admincreate", Service.AdminCheckLogin(), Service.AdminInsertUserEndpoint)
		v1.POST("/user/update", Service.AdminCheckLogin(), Service.AdminUpdateUserEndpoint)
		v1.GET("/file/list", Service.CheckLogin(), Service.FileList)
		v1.GET("/file/delete", Service.CheckLogin(), Service.DeleteFile)
		v1.GET("/login/outLogin", Service.CheckLogin(), Service.UserOutLogin)
		v1.GET("/bill/list", Service.CheckLogin(), Service.ListBill)
		v1.GET("/bill/file/list", Service.CheckLogin(), Service.BillFileList)
		v1.POST("/bill/file/upload", Service.CheckLogin(), Service.BillUploadFile)
		v1.POST("/bill/add",Service.CheckLogin(),Service.InsterBill)
		v1.POST("/upload/file", Service.CheckLogin(), Service.UploadFile)
		v1.POST("/ticket/end", Service.CheckLogin(), Service.EndTicket)
		v1.POST("/ticket/create", Service.CheckLogin(), Service.InsterTicket)
		v1.POST("/ticket/update", Service.CheckLogin(), Service.InsterTicket)
		v1.POST("/dialog/create", Service.CheckLogin(), Service.InsterDialog)
		v1.POST("/user/create", Service.InsertUserEndpoint)
		v1.POST("/user/login", Service.Login)

	}

	// 监听并在 0.0.0.0:8080 上启动服务
	router.Run(":8180")
}
