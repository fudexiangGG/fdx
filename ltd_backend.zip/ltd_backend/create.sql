CREATE TABLE IF NOT EXISTS `users`(
   `id` INT UNSIGNED  AUTO_INCREMENT,
   `username` VARCHAR(255) NOT NULL,
   `mobile` VARCHAR(255) NOT NULL,
   `level` VARCHAR(255) NOT NULL,
   `password` VARCHAR(255) NOT NULL,
   `count` bigint NOT NULL,
   `count_time` bigint NOT NULL,
    `billAmount` bigint NULL ,
   `amount` bigint NOT NULL,
    `role` VARCHAR(255) NOT NULL,
    `create_time` bigint NOT NULL,
     `toekn_time` bigint NOT NULL,
       `token` VARCHAR(255) NOT NULL,
   PRIMARY KEY ( `id` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tickets`(
    `id` INT UNSIGNED  AUTO_INCREMENT,
    `username` VARCHAR(255) NOT NULL,
    `status` VARCHAR(255) NOT NULL,
    `ticket_json` text Not NULL ,
    `create_time` bigint NOT NULL,
    `end_time` bigint NOT NULL,
    `comment` VARCHAR(255) NOT NULL,
    `user_comment_status` VARCHAR(255) NOT NULL,
    `engineer_comment_status` VARCHAR(255) NOT NULL,
    `user_file_status` VARCHAR(255) NOT NULL,
    `engineer_file_status` VARCHAR(255) NOT NULL,
    `score` int NOT NULL,
    PRIMARY KEY ( `id` )
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `bills`(
    `id` INT UNSIGNED  AUTO_INCREMENT,
    `billHeadType` VARCHAR(255)  NULL,
    `billType` VARCHAR(255)  NULL,
    `billHead` VARCHAR(255)  NULL,
    `billIdentifier` VARCHAR(255)  NULL,
    `billAccountBank` VARCHAR(255)  NULL,
    `billAccount` VARCHAR(255)  NULL,
    `billCompanyAddress` VARCHAR(255)  NULL,
    `billCompanyPhone` VARCHAR(255)  NULL,
    `billDownload` VARCHAR(255)  NULL,
    `username` VARCHAR(255)  NOT NULL,
    `billAmount` int NULL ,
    PRIMARY KEY ( `id` )
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `ticket_dialogs`(
    `id` INT UNSIGNED,
    `dialog` text Not NULL ,
   
    PRIMARY KEY ( `id` )
    )ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `notices`(
    `id` INT UNSIGNED AUTO_INCREMENT ,
    `email` VARCHAR(255) NOT NULL,
    PRIMARY KEY ( `id` )
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

