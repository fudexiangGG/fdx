package conf

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v2"
)

type Mysql struct {
	Host string `yaml:"host,omitempty"`
	User string `yaml:"user,omitempty"`
	Pass string `yaml:"pass,omitempty"`
	Db   string `yaml:"db,omitempty"`
} 

type Database struct { 
	Mysql Mysql `yaml:"mysql,omitempty"`
}
	


type Config struct {
	Database Database `yaml:"database,omitempty"`
}


func GetConfig() *Config {
	
	var config Config

	yamlFile, err := os.ReadFile("conf/config.yaml")

	if err != nil {
		fmt.Println(err.Error())
	}

	err = yaml.UnmarshalStrict(yamlFile, &config)

	if err != nil {
		fmt.Println(err.Error())
	}
	return &config

}