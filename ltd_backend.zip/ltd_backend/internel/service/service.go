package service

import (
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/gin"
	"log"
	"ltd_backend/internel/biz"
	"ltd_backend/internel/ltdmail"
	"ltd_backend/internel/transport"
	"math/rand"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type Service struct {
	biz biz.Biz
	log *log.Logger
}

func NewSercice_interface(biz biz.Biz, log *log.Logger) *Service {

	return &Service{
		biz: biz,
		log: log,
	}

}

func isExist(path string) {
	_, err := os.Stat(path)
	if err != nil {

		if os.IsNotExist(err) {
			os.MkdirAll(path, os.ModePerm)
		}

	}

}

func md5crypto(v string) string {
	d := []byte(v)
	m := md5.New()
	m.Write(d)
	return hex.EncodeToString(m.Sum(nil))
}

func GetToken() (string, int64) {

	b := make([]byte, 16)
	rand.Read(b)
	now := time.Now().Unix()
	return fmt.Sprintf("%x", b), now
}

func (s *Service) FilewDownload(c *gin.Context) {
	var dst string
	user, _ := s.GetCookieUser(c)
	id := c.Query("id")
	types := c.Query("type")
	filename := c.Query("filename")
	if types == "bill" {
		_, dst = s.GetBillUserAndDst(id, user)

	}else {
		_, dst = s.GetTicketUserAndDst(id, user)

	}
	c.Header("Content-Type", "application/octet-stream")
	c.Header("Content-Disposition", "attachment; filename="+filename)
	c.Header("Content-Transfer-Encoding", "binary")
	c.File(dst + "/" + filename)

}
func (s *Service) EmialAdd(c *gin.Context) {
	email := c.Query("email")
	err := s.biz.EmailAdd(email)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5551"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": ""})
}

func (s *Service) EmailDelete(c *gin.Context) {

	email := c.Query("email")
	err := s.biz.EmailDlete(email)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5551"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": ""})
}

func (s *Service) EmialList(c *gin.Context) {
	data := s.biz.EmailList()
	c.JSON(http.StatusOK, gin.H{"success": true, "data": data})
}

func (s *Service) UserList(c *gin.Context) {

	userlist, err := s.biz.Userlist()

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5551"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": userlist})

}

func (s *Service) UserOutLogin(c *gin.Context) {
	user, _ := s.GetCookieUser(c)

	err := s.biz.UserOutLogin(user.Username)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5551"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": ""})

}

func (s *Service) EndTicket(c *gin.Context) {
	var err error
	user, _ := s.GetCookieUser(c)

	var endticket transport.EndTicket

	if err = c.ShouldBindJSON(&endticket); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5551"})
		return
	}

	username, _ := s.GetTicketUserAndDst(endticket.Id, user)
	if user.Role == "admin" {

		err = s.biz.EndTicket(&endticket, username, "admin")

	} else {
		err = s.biz.EndTicket(&endticket, user.Username, "guest")
	}

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5551"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": ""})

}

func (s *Service) GetBillUserAndDst(id string, user *biz.User) (string, string) {
	var dst string
	var b *biz.Bill


	if user.Role == "admin" {
		b, _ = s.biz.BillGet(id)
		dst = fmt.Sprintf("/tmp/%s/bill-%s", b.Username, id)
		isExist(dst)
		return b.Username, dst

	} else {
		dst = fmt.Sprintf("/tmp/%s/bill-%s", user.Username, id)
		isExist(dst)
		return user.Username, dst
	}

}

func (s *Service) GetTicketUserAndDst(id string, user *biz.User) (string, string) {
	var dst string
	var t *biz.Ticket


	if user.Role == "admin" {
		t, _ = s.biz.TicketGet(id)
		dst = fmt.Sprintf("/tmp/%s/%s", t.Username, id)
		isExist(dst)
		return t.Username, dst

	} else {
		dst = fmt.Sprintf("/tmp/%s/%s", user.Username, id)
		isExist(dst)
		return user.Username, dst
	}

}

func (s *Service) BillFileList(c *gin.Context) {
	var data []transport.FileList

	user, _ := s.GetCookieUser(c)

	id := c.Query("id")

	_, dst := s.GetBillUserAndDst(id, user)
	var files []string
	filepath.Walk(dst, func(path string, info os.FileInfo, err error) error {
		if info != nil {
			files = append(files, info.Name())

		}

		return nil
	})

	if len(files) > 1 {
		for _, file := range files[1:] {

			data = append(data, transport.FileList{Name: file, Stutus: "done", Url: fmt.Sprintf("/v1/file/download?type=bill&id=%s&filename=%s", id, file)})
		}

	}

	s.biz.UpdateTicketCommentFileStatus("0", "file", id, user.Role)

	c.JSON(http.StatusOK, data)
}

func (s *Service) FileList(c *gin.Context) {
	var data []transport.FileList

	user, err := s.GetCookieUser(c)

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})

	}

	id := c.Query("id")

	_, dst := s.GetTicketUserAndDst(id, user)
	var files []string
	err = filepath.Walk(dst, func(path string, info os.FileInfo, err error) error {
		if info != nil {
			files = append(files, info.Name())

		}

		return nil
	})

	if len(files) > 1 {
		for _, file := range files[1:] {

			data = append(data, transport.FileList{Name: file, Stutus: "done", Url: fmt.Sprintf("/v1/file/download?id=%s&filename=%s", id, file)})
		}

	}

	s.biz.UpdateTicketCommentFileStatus("0", "file", id, user.Role)

	c.JSON(http.StatusOK, data)
}

func (s *Service) DeleteFile(c *gin.Context) {
	user, err := s.GetCookieUser(c)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}
	id := c.Query("id")
	filename := c.Query("filename")
	_, dst := s.GetTicketUserAndDst(id, user)

	os.Remove(dst + "/" + filename)

	c.JSON(http.StatusOK, gin.H{"success": true, "data": ""})
}

func (s *Service) BillUploadFile(c *gin.Context) {
	file, _ := c.FormFile("files")

	user, err := s.GetCookieUser(c)

	id := c.Query("id")
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return
	}
	_, dst := s.GetBillUserAndDst(id, user)

	if user.Role == "admin" {
		err = c.SaveUploadedFile(file, fmt.Sprintf("%s/EngineerRespone_%s", dst, file.Filename))
	} else {
		err = c.SaveUploadedFile(file, dst+"/"+file.Filename)
	}
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"status": err.Error(), "name": file.Filename})
		return
	}
	s.biz.UpdateTicketCommentFileStatus("1", "file", id, user.Role)

	if user.Role == "admin" {
		c.JSON(http.StatusOK, gin.H{"status": "done", "name": fmt.Sprintf("EngineerRespone_%s", file.Filename), "url": fmt.Sprintf("/v1/file/download?id=%s&filename=EngineerRespone_%s", id, file.Filename)})
		return
	}

	c.JSON(http.StatusOK, gin.H{"status": "done", "name": file.Filename, "url": fmt.Sprintf("/v1/file/download?id=%s&filename=%s", id, file.Filename)})
}

func (s *Service) UploadFile(c *gin.Context) {
	file, _ := c.FormFile("files")

	user, err := s.GetCookieUser(c)

	id := c.Query("id")
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return
	}
	_, dst := s.GetTicketUserAndDst(id, user)

	if user.Role == "admin" {
		err = c.SaveUploadedFile(file, fmt.Sprintf("%s/EngineerRespone_%s", dst, file.Filename))
	} else {
		err = c.SaveUploadedFile(file, dst+"/"+file.Filename)
	}
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"status": err.Error(), "name": file.Filename})
		return
	}
	s.biz.UpdateTicketCommentFileStatus("1", "file", id, user.Role)

	if user.Role == "admin" {
		c.JSON(http.StatusOK, gin.H{"status": "done", "name": fmt.Sprintf("EngineerRespone_%s", file.Filename), "url": fmt.Sprintf("/v1/file/download?id=%s&filename=EngineerRespone_%s", id, file.Filename)})
		return
	}

	c.JSON(http.StatusOK, gin.H{"status": "done", "name": file.Filename, "url": fmt.Sprintf("/v1/file/download?id=%s&filename=%s", id, file.Filename)})
}

func (s *Service) GetVerifiyCode(c *gin.Context) {
	username := c.Query("username")
	code := RandStr(8)
	println(username)
	err :=  ltdmail.EmailSend(username,code)
	if err != nil {
		println(err.Error())
	}
}

func (s *Service) Login(c *gin.Context) {
	var user transport.User


	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "loginType": "account", "errorCode": "5551"})
		return
	}

	srcUser, err := s.biz.GetUser(user.Username)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "loginType": "account", "errorCode": "5551"})
		return
	}

	if md5crypto(user.Password) != srcUser.Password {

		c.JSON(http.StatusOK, gin.H{"errorMessage": "密码不正确!", "success": true, "data": "密码不正确!", "loginType": "account", "errorCode": "5551", "status": "密码不正确!"})
		return
	}

	token, time := GetToken()

	if err := s.biz.UpdateToken(user.Username, token, time); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "Token fail!", "loginType": "account", "errorCode": "5551"})
		return
	}

	c.SetCookie("ltd_token", user.Username+":"+token, 28800, "/", "127.0.0.1", false, true)
	srcUser.Password = ""
	c.JSON(http.StatusOK, gin.H{"success": true, "data": "", "loginType": "account", "status": "ok"})

}

func (s *Service) GetCookieUser(c *gin.Context) (*biz.User, error) {
	cookie, err := c.Cookie("ltd_token")
	if err != nil {
		return nil, err
	}
	co := strings.Split(cookie, ":")
	return s.biz.GetUser(co[0])

}

func (s *Service) TicketDialogGet(c *gin.Context) {
	id := c.Query("id")
	user, _ := s.GetCookieUser(c)

	dialog, err := s.biz.TicketDialogGet(id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})

	}

	if dialog == nil {
		c.JSON(http.StatusOK, gin.H{"success": true, "data": ""})
	}

	req, err := decodeDialog(dialog.Dialog)

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})

	}

	s.biz.UpdateTicketCommentFileStatus("0", "comment", id, user.Role)

	c.JSON(http.StatusOK, req)

}




func(s *Service) ListBill(c *gin.Context) {
	user, _ := s.GetCookieUser(c)

	bizlist,err := s.biz.ListBill(user.Username)

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return
	}

	c.JSON(http.StatusOK, gin.H{ "success": true, "data": bizlist})


}

func(s *Service) InsterBill(c *gin.Context) {
	user, _ := s.GetCookieUser(c)
	var bill biz.Bill

	if err := c.ShouldBindJSON(&bill); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5551"})
		return
	}
	if bill.BillHeadType == "personal" {
		bill.BillHead = "personal"
	}
	bill.Username = user.Username
	bill.BillDownload = "相关人员处理中,请耐心等待!"
	err := s.biz.InsterBill(&bill)

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return
	}

	c.JSON(http.StatusOK, gin.H{ "success": true, "data": ""})


}
func RandStr(length int) string {
	str := "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	bytes := []byte(str)
	result := []byte{}
	rand.Seed(time.Now().UnixNano()+ int64(rand.Intn(100)))
	for i := 0; i < length; i++ {
		result = append(result, bytes[rand.Intn(len(bytes))])
	}
	return string(result)
}

func (s *Service) CurrentUser(c *gin.Context) {
	user, err := s.GetCookieUser(c)

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})

	}

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return
	}

	user.Password = " "
	c.JSON(http.StatusOK, gin.H{"success": true, "data": user, "username": user.Username, "mobile": user.Mobile, "level": user.Level, "role": user.Role, "id": user.Id,"amount":user.Amount})

}

func commonencode(tikect interface{}) ([]byte, error) {
	t, err := json.Marshal(tikect)
	if err != nil {
		return nil, err
	}
	return t, nil
}

func decodeDialog(t string) (transport.DialogReq, error) {
	var dialog transport.DialogReq
	err := json.Unmarshal([]byte(t), &dialog)
	if err != nil {
		return transport.DialogReq{}, err
	}
	return dialog, nil
}

func decodeTicket(t string) (biz.NewTikect, error) {
	var ticket biz.NewTikect
	err := json.Unmarshal([]byte(t), &ticket)
	if err != nil {
		return biz.NewTikect{}, err
	}
	return ticket, nil
}

func (s *Service) TicketGet(c *gin.Context) {
	id := c.Query("id")
	ticket, err := s.biz.TicketGet(id)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return

	}
	t, err := decodeTicket(ticket.TicketJson)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return

	}
	c.JSON(http.StatusOK, t)

}

func (s *Service) EndTicketList(c *gin.Context) {
	username := c.Query("username")
	var ticketlist []biz.Ticket
	user, err := s.GetCookieUser(c)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}
	if user.Role == "admin" {

		ticketlist, err = s.biz.EndTicketList(user.Username, username)

	} else {
		ticketlist, err = s.biz.EndTicketList(user.Username, "")

	}

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": ticketlist})
}

func (s *Service) TicketList(c *gin.Context) {
	status := c.Query("status")
	username := c.Query("username")
	var ticketlist []biz.Ticket
	user, err := s.GetCookieUser(c)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}
	if user.Role == "admin" {

		if status == "" && username == "" {
			ticketlist, err = s.biz.TicketList(user.Username, "", "")

		} else if username != "" && status == "" {
			ticketlist, err = s.biz.TicketList(user.Username, "", username)

		} else if status != "" && username == "" {
			ticketlist, err = s.biz.TicketList(user.Username, status, "")

		} else {
			ticketlist, err = s.biz.TicketList(user.Username, status, username)

		}

	} else {
		ticketlist, err = s.biz.TicketList(user.Username, status, "")

	}

	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": ticketlist})
}

func (s *Service) InsterDialog(c *gin.Context) {
	var dialog transport.DialogReq
	var newdialog transport.DialogReq
	user, _ := s.GetCookieUser(c)
	if err := c.ShouldBindJSON(&dialog); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": false, "data": "", "errorCode": "5552"})
		return
	}

	for _, v := range dialog.Data {
		if v.Data != "" {
			newdialog.Data = append(newdialog.Data, v)
		}
	}

	if newdialog.Data == nil {
		c.JSON(http.StatusOK, gin.H{"status": "", "success": true, "data": "no message"})
		return
	}

	data, _ := commonencode(newdialog)
	srcdialog, _ := s.biz.TicketDialogGet(dialog.Data[0].Id)
	if srcdialog != nil {
		if srcdialog.Dialog == string(data) {
			c.JSON(http.StatusOK, gin.H{"success": true, "data": "创建成功"})
			return
		}
	}

	if err := s.biz.TicketDialogInster(&biz.TicketDialog{Id: dialog.Data[0].Id, Dialog: string(data)}); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": false, "data": "", "errorCode": "5552"})
		return

	}

	s.biz.UpdateTicketCommentFileStatus("1", "comment", dialog.Data[0].Id, user.Role)

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "创建成功"})
}

func (s *Service) InsterTicket(c *gin.Context) {
	var ticket biz.Ticket
	var newticket biz.NewTikect
	user, err := s.GetCookieUser(c)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5555"})
		return

	}

	if err := c.ShouldBindJSON(&newticket); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": false, "data": "", "errorCode": "5552"})
		return
	}

	now := time.Now().UnixMilli()
	t, err := commonencode(&newticket)
	if err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5552"})
	}
	ticket.TicketJson = string(t)
	ticket.Username = user.Username
	ticket.CreateTime = now
	ticket.Status = "0"
	ticket.Score = 0
	ticket.Comment = ""
	ticket.EngineerCommentStatus = "0"
	ticket.UserFileStatus = "0"
	ticket.UserCommentStatus = "0"
	ticket.EngineerFileStatus = "0"
	ticket.EndTime = 0
	if err := s.biz.InsterTicket(&ticket); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": false, "data": "", "errorCode": "5552"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "创建成功"})

}

func GetLevel(c int64) string {
	var level string

	switch {
	case c >= 12:
		level = "3"
	case c >= 3:
		level = "2"
	case c >= 1:
		level = "1"
	default:
		level = "0"
	}
	return level
}

func (s *Service) AdminDeleteUser(c *gin.Context) {
	username := c.Query("username")
	if err := s.biz.DeleteUser(username); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"success": true, "data": "success", "status": "ok"})

}

func (s *Service) AdminUpdateUserEndpoint(c *gin.Context) {
	var user transport.AdminUser
	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5552"})
		return
	}

	if err := s.biz.UpdateUser(&biz.User{Level: GetLevel(user.CountTime), Username: user.Username, Mobile: user.Mobile, Count: user.Count, Amount: user.Amount, CountTime: user.CountTime}); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "success", "status": "ok"})
}

func (s *Service) AdminInsertUserEndpoint(c *gin.Context) {
	var user transport.AdminUser

	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5552"})
		return
	}

	now := time.Now().UnixMilli()
	if err := s.biz.InsertUser(&biz.User{Username: user.Username, Password: md5crypto(user.Password), Mobile: user.Mobile, CreateTime: now,
		Level: GetLevel(user.CountTime), Count: user.Count, BillAmount: user.Amount,Amount: user.Amount, CountTime: user.CountTime, Role: "guest", Token: " ", ToeknTime: 0}); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "success", "status": "ok"})
}

func (s *Service) InsertUserEndpoint(c *gin.Context) {
	var user transport.UserRegister

	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5552"})
		return
	}

	now := time.Now().UnixMilli()
	if err := s.biz.InsertUser(&biz.User{Username: user.Username, Password: md5crypto(user.Password), Mobile: user.Mobile, CreateTime: now,
		Level: "0", Count: 0, CountTime: 0, Amount: 0, Role: "guest", Token: " ", ToeknTime: 0}); err != nil {

		c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "status": err.Error(), "success": true, "data": "", "errorCode": "5555"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"success": true, "data": "success", "status": "ok"})
}

func (s *Service) CheckLogin() gin.HandlerFunc {

	return func(c *gin.Context) {
		cookie, err := c.Cookie("ltd_token")

		if err != nil {
			c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}

		co := strings.Split(cookie, ":")

		user, err := s.biz.GetUser(co[0])
		if err != nil {
			c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}
		if user.Token != co[1] {
			c.JSON(http.StatusOK, gin.H{"errorMessage": "Token fail!", "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}

	}
}

func (s *Service) AdminCheckLogin() gin.HandlerFunc {

	return func(c *gin.Context) {
		cookie, err := c.Cookie("ltd_token")

		if err != nil {
			c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}

		co := strings.Split(cookie, ":")

		user, err := s.biz.GetUser(co[0])
		if user.Role != "admin" {
			c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return
		}
		if err != nil {
			c.JSON(http.StatusOK, gin.H{"errorMessage": err.Error(), "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}
		if user.Token != co[1] {
			c.JSON(http.StatusOK, gin.H{"errorMessage": "Token fail!", "success": true, "data": "", "errorCode": "5555"})
			c.Abort()
			return

		}

	}
}
