package transport

type LoginRes struct {
	Status string `json:"status,omitempty"` 
}
type User  struct {
	Username     string `form:"username" json:"username" xml:"username"  binding:"required"`
	Password string `form:"password" json:"password" xml:"password" binding:"required"`
}

type UserRegister struct {
	Username     string `form:"username" json:"username" xml:"username"  binding:"required"`
	Password string `form:"password" json:"password" xml:"password" binding:"required"`
	Mobile string `form:"mobile" json:"mobile" xml:"mobile" binding:"required"`
	Captcha string `form:"captcha" json:"captcha" xml:"captcha" binding:"required"`
}

